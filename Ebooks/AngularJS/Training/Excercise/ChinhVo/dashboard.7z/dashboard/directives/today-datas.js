﻿(function () {
    var todayDatas = function () {
        return {
            restrict: 'A',      
            transclude: true,
            controller: "todayDatasCtrl",
            templateUrl: "app/dashboard/directives/todayDatas.html",
            scope: {
                icon: '@',
                value: "=",
                category:"@"
            },
            link: function (scope, element, attrs) {
                debugger
            }
        };
    };

    angular.module('app').directive('todayDatas', todayDatas);

}());