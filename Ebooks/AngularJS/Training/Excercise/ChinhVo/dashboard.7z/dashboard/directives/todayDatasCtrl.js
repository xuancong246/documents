﻿(function () {

    var injectParams = [];

    var todayDatasCtrl = function () {

    };

    todayDatasCtrl.$inject = injectParams;

    angular.module('app').controller('todayDatasCtrl', todayDatasCtrl);

}());