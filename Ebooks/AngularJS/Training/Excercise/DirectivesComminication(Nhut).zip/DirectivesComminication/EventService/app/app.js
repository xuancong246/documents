(function () {
    'use strict';
    var app = angular.module('app', [])
        .directive('speakers',['$rootScope',function($rootScope){
            return {
                restrict: 'E',
                scope: true,
                templateUrl: 'app/speakers/speakers.html',
                controller: function($scope){
                    $scope.delete = function(speaker){
                        for (var i = 0; i < $scope.listSpeakers.length; i ++){
                            if($scope.listSpeakers[i].id === speaker.id){
                                $scope.listSpeakers.splice(i,1);
                            }
                        }
                        $rootScope.$broadcast('UPDATE_SPEAKERS_QUANTITY', $scope.listSpeakers.length);
                    };
                    $scope.listSpeakers = (function(){
                        var arr = [];
                        for (var i = 0;i < 10 ;i ++){
                            arr.push({
                                id: i,
                                name: 'Speaker-' + i
                            })
                        }
                        $rootScope.$broadcast('UPDATE_SPEAKERS_QUANTITY', arr.length);
                        return arr;
                    })();
                }
            };
        }])
        .directive('speakersWidget',[function(){
            return {
                restrict: 'E',
                scope: true,
                templateUrl: 'app/speakers/speakers-widget.html',
                link: function(scope){
                    scope.$on('UPDATE_SPEAKERS_QUANTITY', function(evt, quantity){
                        scope.quantity = quantity;
                    })
                    
                }
            };
        }]);
})();