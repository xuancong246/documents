(function () {
    'use strict';
    var app = angular.module('app', [])
        .controller('appCtrl', ['$scope', function($scope){
            $scope.speakersWidget = {
                quantity: 10
            };
            $scope.speakers = {
                delete: function(speaker){
                    for (var i = 0; i < $scope.speakers.listSpeakers.length; i ++){
                        if($scope.speakers.listSpeakers[i].id === speaker.id){
                            $scope.speakers.listSpeakers.splice(i,1);
                        }
                    }
                    $scope.speakersWidget.quantity--;
                },
                listSpeakers : (function(){
                    var arr = [];
                    for (var i = 0;i < $scope.speakersWidget.quantity; i ++){
                        arr.push({
                            id: i,
                            name: 'Speaker-' + i
                        })
                    }
                    return arr;
                })()

            };
        }])
        .directive('speakers',[function(){
            return {
                restrict: 'E',
                templateUrl: 'app/speakers/speakers.html'
            };
        }])
        .directive('speakersWidget',[function(){
            return {
                restrict: 'E',
                templateUrl: 'app/speakers/speakers-widget.html'
            };
        }]);
})();