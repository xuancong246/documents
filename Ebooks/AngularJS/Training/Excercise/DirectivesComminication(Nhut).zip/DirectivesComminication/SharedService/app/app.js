(function () {
    'use strict';
    var app = angular.module('app', [])
        .factory('sharedSvc', [function(){
            var self = this;
            var speakersWidget = {
                data: {
                    quantity: 10
                }
            };
            var speakers = {
                listSpeakers: {
                    data: (function(){
                        var arr = [];
                        for (var i = 0;i < speakersWidget.data.quantity; i ++){
                            arr.push({
                                id: i,
                                name: 'Speaker-' + i
                            })
                        }
                        return arr;
                    })()
                }
            };

            return {
                speakersWidget: speakersWidget,
                speakers: speakers
            }
        }])
        .directive('speakers',['sharedSvc',function(sharedSvc){
            return {
                restrict: 'E',
                scope: true,
                templateUrl: 'app/speakers/speakers.html',
                controller: function($scope){
                    $scope.delete = function(speaker){
                        for (var i = 0; i < sharedSvc.speakers.listSpeakers.data.length; i ++){
                            if(sharedSvc.speakers.listSpeakers.data[i].id === speaker.id){
                                sharedSvc.speakers.listSpeakers.data.splice(i,1);
                            }
                        }
                        sharedSvc.speakersWidget.data.quantity--;
                    };
                    $scope.listSpeakers = sharedSvc.speakers.listSpeakers;
                }
            };
        }])
        .directive('speakersWidget',['sharedSvc',function(sharedSvc){
            return {
                restrict: 'E',
                scope: true,
                templateUrl: 'app/speakers/speakers-widget.html',
                link: function(scope){
                    scope.speakersWidget = sharedSvc.speakersWidget;
                }
            };
        }]);
})();