﻿(function () {
    'use strict';

    angular
        .module('svt')
        .service('pageSvc', pageSvc);

    pageSvc.$inject = ['pageDataSvc'];

    function pageSvc(pageDataSvc) {
        var pages = { data: [] };
        var generalConstant = {
            NOT_FOUND: -1
        };
        var isShowPageEditor = { value: {} };
        var idToShowPageEditor = { value: '' };

        var service = {
            getAll: getAll,
            addPage: addPage,
            updatePage: updatePage,
            deletePage: deletePage,
            getAllBySurveyId: getAllBySurveyId,
            getIdToShowPageEditor: getIdToShowPageEditor,
            getIsShowPageEditor: getIsShowPageEditor,
            getPageIndexByPageId: getPageIndexByPageId,
            hidePageEditor: hidePageEditor,
            setIdToShowPageEditor: setIdToShowPageEditor,
            toggleIsShowPageEditor: toggleIsShowPageEditor,
            findPageIndexById: findPageIndexById,
            movePage: movePage,
            isThankYouPage: isThankYouPage
        };

        return service;

        function getAll() {
            return pages.data;
        }

        function addPage(currentPagePosition, surveyId, parentId) {
            var page = {
                Id: null,
                Name: 'Untitled',
                Position: currentPagePosition + 1,
                SurveyId: surveyId,
                ParentId: parentId,
                ResponseStatus: 'NotTaken'
            };
            return pageDataSvc.addPage(page);
        }

        function deletePage(page) {
            return pageDataSvc.deletePage(page);
        }

        function updatePage(page) {
            return pageDataSvc.updatePage(page);
        }

        function getAllBySurveyId(surveyId) {
            pages.data = [];
            pageDataSvc.getAllBySurveyId(surveyId).$promise.then(function(data) {
                for (var i = 0; i < data.length; i++) {
                    pages.data.push(data[i]);
                }
            });
            return pages;
        }

        function getIdToShowPageEditor() {
            return idToShowPageEditor.value;
        }

        function getIsShowPageEditor() {
            return isShowPageEditor;
        }

        function getPageIndexByPageId(pageId) {
            for (var pageIndex in pages.data) {
                if (pages.data[pageIndex].id === pageId) {
                    return pageIndex;
                }
            }
            return null;
        }

        function hidePageEditor() {
            for (var index in isShowPageEditor.value) {
                if (isShowPageEditor.value.hasOwnProperty(index))
                    isShowPageEditor.value[index] = false;
            }
        }

        function setIdToShowPageEditor(id) {
            idToShowPageEditor.value = id;
        }

        function toggleIsShowPageEditor() {
            isShowPageEditor.value[idToShowPageEditor.value] = !isShowPageEditor.value[idToShowPageEditor.value];
        }

        function findPageIndexById(array, value) {
            for (var i = 0; i < array.length; i++) {
                if (array[i].Id === value) {
                    return i;
                }
            }
            return generalConstant.NOT_FOUND;
        }

        function movePage(item) {
            return pageDataSvc.movePage(item);
        }

        function isThankYouPage(page) {
            return page.NodeType === 'ThankYouPage';
        }
    }
})();