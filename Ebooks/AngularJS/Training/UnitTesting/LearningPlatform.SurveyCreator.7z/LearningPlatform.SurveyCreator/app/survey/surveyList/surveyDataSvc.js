﻿(function () {
    'use strict';

    angular
        .module('svt')
        .factory('surveyDataSvc', surveyDataSvc);

    surveyDataSvc.$inject = ['$resource', 'host'];

    function surveyDataSvc($resource, host) {
        var dataService = {
            getAllSurveys: getAllSurveys,
            deleteSurvey: deleteSurvey,
            count: count,
            search: search
        };

        return dataService;

        function count(countForm) {
            return $resource(host + '/surveys/count', { searchString: '@searchString' }, { 'count': { method: 'GET' } }).count({ searchString: countForm.searchString });
        }

        function search(searchForm) {
            return $resource(host + '/surveys/search', { searchString: '@searchString', start: '@start', limit: '@limit' }, { 'search': { method: 'GET', isArray: true } })
                .search({
                    searchString: searchForm.searchString,
                    start: searchForm.paging.start,
                    limit: searchForm.paging.limit
                });
        }

        function deleteSurvey(surveyId) {
            return $resource(host + '/surveys/:surveyId/definition', { surveyId: '@surveyId' }, { 'deleteSurvey': { method: 'DELETE' } }).deleteSurvey({ surveyId: surveyId });
        }

        function getAllSurveys() {
            return $resource(host + '/surveys', { surveyId: '@surveyId' }, { 'getAllSurveys': { method: 'GET', isArray: true } }).getAllSurveys({ });
        }
    }
})();