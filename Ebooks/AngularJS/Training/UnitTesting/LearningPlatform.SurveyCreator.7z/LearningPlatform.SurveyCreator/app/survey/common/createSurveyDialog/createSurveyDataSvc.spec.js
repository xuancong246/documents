﻿(function() {
    'use strict';
    describe('Testing createSurveyDataSvc service', function() {
        var httpBackend,
            createSurveyDataSvc,
            hostMock = 'http://localhost:52071/api';

        beforeEach(function() {
            module('svt');
            inject(function($injector) {
                httpBackend = $injector.get('$httpBackend');
                createSurveyDataSvc = $injector.get('createSurveyDataSvc');
            });
        });

        describe('Testing addSurvey function', function() {
            it('should add survey successfully', function() {
                httpBackend.expectPOST(hostMock + '/surveys/0/definition').respond({ result: true });
                var result = createSurveyDataSvc.addSurvey(null);
                httpBackend.flush();

                expect(angular.toJson(result)).toContain('result');
            });
        });

        describe('Testing updateSurvey function', function() {
            it('should update survey successfully', function() {
                var survey = { SurveyId: 1 };
                httpBackend.expectPUT(hostMock + '/surveys/1/definition').respond({ result: true });
                var result = createSurveyDataSvc.updateSurvey(survey);
                httpBackend.flush();

                expect(angular.toJson(result)).toContain('result');
            });
        });
    });
})();