﻿(function() {
    'use strict';

    var host = '/* @echo surveyAPIUrl */';
    /* @ifndef surveyAPIUrl */
    host = 'http://localhost:52071/api';
    /*@endif*/

    angular
        .module('svt')
        .constant('host', host);
})();