﻿(function () {
    'use strict';
    describe('Testing questionDataSvc service', function () {
        var httpBackend,
            questionDataSvc,
            hostMock = 'http://localhost:52071/api';

        beforeEach(function () {
            module('svt');
            inject(function ($injector) {
                httpBackend = $injector.get('$httpBackend');
                questionDataSvc = $injector.get('questionDataSvc');
            });
        });

        describe('Testing getAllById function', function() {
            it('should return all of question based on survey ID and Page ID', function() {
                httpBackend.expectGET(hostMock + '/surveys/3/definition/pages/4/questions').respond([{ name: 'a' }, { name: 'b' }, { name: 'c' }]);
                var result = questionDataSvc.getAllById(3, 4);
                httpBackend.flush();
                var expectedResult = [{ name: 'a' }, { name: 'b' }, { name: 'c' }];
                expect(angular.toJson(result)).toEqual(angular.toJson(expectedResult));
            });
        });

        describe('Testing AddNew function', function () {
            it('should add the new question', function () {
                var questionMock = {
                    SurveyId: '3'
                };
                httpBackend.expectPOST(hostMock + '/surveys/3/definition/questions').respond({ result: true });
                var result = questionDataSvc.addNew(questionMock);
                httpBackend.flush();
                expect(angular.toJson(result)).toContain('result');
            });
        });

        describe('Testing updateById function', function () {
            it('should update question by id', function () {
                var questionMock = {
                    SurveyId: '3',
                    Id: '4'
                };
                httpBackend.expectPUT(hostMock + '/surveys/3/definition/questions/4').respond({ result: true });
                var result = questionDataSvc.updateById(questionMock);
                httpBackend.flush();
                expect(angular.toJson(result)).toContain('result');
            });
        });

        describe('Testing deleteById function', function () {
            it('should delete question', function () {
                var questionMock = {
                    SurveyId: '3',
                    Id: '4'
                };
                httpBackend.expectDELETE(hostMock + '/surveys/3/definition/questions/4').respond({ result: true });
                var result = questionDataSvc.deleteById(questionMock);
                httpBackend.flush();
                expect(angular.toJson(result)).toContain('result');
            });
        });

        describe('Testing moveToAnotherPage function', function () {
            it('should move question to another page', function () {
                var movingquestionMock = {
                    SurveyId: '3',
                    DeparturePageId: '4'
                };
                httpBackend.expectPATCH(hostMock + '/surveys/3/pages/4/questions').respond({ result: true });
                var result = questionDataSvc.moveToAnotherPage(movingquestionMock);
                httpBackend.flush();
                expect(angular.toJson(result)).toContain('result');
            });
        });

        describe('Testing moveInsidePage function', function () {
            it('should move question inside page', function () {
                var movingquestionMock = {
                    SurveyId: '3',
                    DeparturePageId: '4',
                    QuestionId: '5'
                };
                httpBackend.expectPATCH(hostMock + '/surveys/3/pages/4/questions/5').respond({ result: true });
                var result = questionDataSvc.moveInsidePage(movingquestionMock);
                httpBackend.flush();
                expect(angular.toJson(result)).toContain('result');
            });
        });

        afterEach(function () {
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();
        });
    });
})();