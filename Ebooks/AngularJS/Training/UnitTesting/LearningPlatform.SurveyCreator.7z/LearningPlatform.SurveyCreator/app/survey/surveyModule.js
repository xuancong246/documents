﻿(function () {
    'use strict';
    angular.module('svt', [
            'angularModalService',
            'ngRoute',
            'ngResource',
            'ui.sortable', 'angularSpinner'])
        .config(['$routeProvider', 'usSpinnerConfigProvider', function ($routeProvider, usSpinnerConfigProvider) {
            $routeProvider.when('/surveys', { templateUrl: 'survey/surveyList/surveys.html' });
            $routeProvider.when('/surveydashboard/:id', { templateUrl: 'survey/dashboard/surveyDashboard.html', controller: 'surveyDashboardCtrl' });
            $routeProvider.when('/editsurvey/:id', { templateUrl: 'survey/surveyEditor/surveyEditor.html' });
            $routeProvider.when('/testsurvey/:id', { templateUrl: 'survey/testSurvey/testSurvey.html' });
            $routeProvider.when('/collectResponses/:id', { templateUrl: 'survey/collectResponses/collectResponses.html' });
            $routeProvider.otherwise({ redirectTo: '/surveys' });
            usSpinnerConfigProvider.setDefaults({ color: '#337ab7' });
        }]);
})();
