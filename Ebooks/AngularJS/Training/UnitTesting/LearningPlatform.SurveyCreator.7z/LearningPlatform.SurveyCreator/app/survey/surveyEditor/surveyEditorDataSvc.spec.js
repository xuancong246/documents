﻿(function() {
    'use strict';
    describe('Testing surveyEditorDataSvc service', function () {
        var httpBackend,
            surveyEditorDataSvc,
            hostMock = 'http://localhost:52071/api';

        beforeEach(function () {
            module('svt');
            inject(function ($injector) {
                httpBackend = $injector.get('$httpBackend');
                surveyEditorDataSvc = $injector.get('surveyEditorDataSvc');
            });
        });

        describe('Testing getSurvey function', function () {
            it('should return survey', function () {
                var surveyId = 1;
                httpBackend.expectGET(hostMock + '/surveys/1/definition').respond({ id: 1, name: 'abc' });
                var result = surveyEditorDataSvc.getSurvey(surveyId);
                httpBackend.flush();
                var expectedSurvey = {id: 1, name: 'abc'};
                expect(angular.toJson(result)).toEqual(angular.toJson(expectedSurvey));
            });
        });
    });
})();