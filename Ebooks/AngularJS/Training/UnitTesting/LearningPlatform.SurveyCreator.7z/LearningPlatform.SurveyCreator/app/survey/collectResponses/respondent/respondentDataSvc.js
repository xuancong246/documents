﻿(function () {
    'use strict';

    angular
        .module('svt')
        .factory('respondentDataSvc', respondentDataSvc);

    respondentDataSvc.$inject = ['$resource', 'host'];

    function respondentDataSvc($resource, host) {
        var dataService = {
            upload: upload,
            sendEmail: sendEmail,
            testSendEmail: testSendEmail
        };

        return dataService;

        function upload(surveyId, respondentFile) {
            var uploadForm = new FormData();
            uploadForm.append('respondentFile', respondentFile);
            return $resource(host + '/surveys/:surveyId/respondents/upload', { surveyId: '@surveyId' }, { 'upload': { method: 'POST', transformRequest: angular.identity, headers: { 'Content-Type': undefined } } })
                        .upload({ surveyId: surveyId }, uploadForm);
        }

        function sendEmail(surveyId, sendRespondentForm) {
            return $resource(host + '/surveys/:surveyId/respondents/send', { surveyId: '@surveyId'}, { 'sendEmail': { method: 'POST' } })
                        .sendEmail({ surveyId: surveyId }, JSON.stringify(sendRespondentForm));
        }

        function testSendEmail(surveyId, sendRespondentForm) {
            return $resource(host + '/surveys/:surveyId/respondents/testsend', { surveyId: '@surveyId' }, { 'testSendEmail': { method: 'POST' } })
                        .testSendEmail({ surveyId: surveyId }, JSON.stringify(sendRespondentForm));
        }
    }
})();