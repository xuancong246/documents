﻿(function () {
    'use strict';

    angular
        .module('svt')
        .controller('surveyMenuCtrl', surveyMenuCtrl);

    surveyMenuCtrl.$inject = ['$scope', '$routeParams', '$location'];

    function surveyMenuCtrl($scope, $routeParams, $location) {
        /* jshint -W040 */
        var vm = this;

        vm.menus = [
                    {
                        id: 1,
                        name: 'Survey dashboard',
                        active: false,
                        path: '/surveydashboard/' + $routeParams.id
                    },
                    {
                        id: 2,
                        name: 'Edit Survey',
                        active: false,
                        path: '/editsurvey/' + $routeParams.id
                    },
                    {
                        id: 3,
                        name: 'Collect Responses',
                        active: false,
                        path: '/collectResponses/' + $routeParams.id
                    },
                    {
                        id: 4,
                        name: 'Analyze Results',
                        active: false,
                        path: '/surveydashboard/' + $routeParams.id
                    }
        ];

        vm.navigate = function (menu) {
            $location.path(menu.path);
        };

        function activeMenu(menuName) {
            for (var i = 0; i < vm.menus.length; i++) {
                vm.menus[i].active = vm.menus[i].name.indexOf(menuName) > -1;
            }
        }

        activeMenu($scope.activeMenu);
    }
})();
