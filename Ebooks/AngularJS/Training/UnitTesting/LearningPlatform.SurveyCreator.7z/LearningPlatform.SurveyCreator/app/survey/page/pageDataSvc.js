﻿(function () {
    'use strict';

    angular
        .module('svt')
        .factory('pageDataSvc', pageDataSvc);

    pageDataSvc.$inject = ['$resource', 'host'];

    function pageDataSvc($resource, host) {
        var dataService = {
            addPage: addPage,
            updatePage: updatePage,
            deletePage: deletePage,
            getAllBySurveyId: getAllBySurveyId,
            movePage: movePage
        };

        return dataService;

        function addPage(page) {
            return $resource(host + '/surveys/:surveyId/definition/pages', { surveyId: '@surveyId' }, { 'AddPage': { method: 'POST' } })
                .AddPage({ surveyId: page.SurveyId }, JSON.stringify(page));
        }

        function updatePage(page) {
            return $resource(host + '/surveys/:surveyId/definition/pages/:pageId', { surveyId: '@surveyId', pageId: '@pageId' }, { 'update': { method: 'PUT' } })
                .update({ surveyId: page.SurveyId, pageId: page.Id }, JSON.stringify(page));
        }

        function deletePage(page) {
            return $resource(host + '/surveys/:surveyId/definition/pages/:pageId', { surveyId: '@surveyId', pageID: '@pageID' }, { 'DeleteById': { method: 'DELETE' } })
                .DeleteById({ surveyId: page.SurveyId, pageId: page.Id });
        }

        function getAllBySurveyId(surveyId) {
            return $resource(host + '/surveys/:surveyId/definition/pages', { surveyId: '@surveyId' }, { 'GetAllBySurveyId': { method: 'GET', isArray: true } })
                .GetAllBySurveyId({ surveyId: surveyId });
        }

        function movePage(item) {
            return $resource(host + '/surveys/:surveyId/pages', { surveyId: '@surveyId' }, { 'MovePage': { method: 'PATCH' } })
                .MovePage({ surveyId: item.SurveyId }, JSON.stringify(item));
        }
    }
})();