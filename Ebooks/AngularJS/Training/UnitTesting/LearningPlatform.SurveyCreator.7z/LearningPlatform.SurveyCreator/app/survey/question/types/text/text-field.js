﻿(function () {
    'use strict';

    angular
        .module('svt')
        .directive('textField', textQuestion);

    function textQuestion() {
        var directive = {
            restrict: 'E',
            templateUrl: 'survey/question/types/text/text-field.html'
        };

        return directive;
    }
})();