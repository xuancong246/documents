﻿(function() {
    'use strict';

    angular
        .module('svt')
        .service('constantSvc', constantSvc);

    function constantSvc() {
        var messages = {
            deletePage: 'All questions in this page will be deleted too! Are you sure you want to delete it?',
            deleteQuestion: 'Are you sure want to delete this question?',
            deleteSurvey: 'Are you sure want to delete this survey?'
        };

        var url = {
            testUrl: 'http://localhost:52071/survey/test/'
            };

        var service = {
            messages: messages,
            url:url
        };

        return service;
    }
})();