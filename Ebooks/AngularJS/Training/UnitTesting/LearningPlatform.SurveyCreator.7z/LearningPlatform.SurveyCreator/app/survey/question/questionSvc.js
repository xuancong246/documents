﻿(function () {
    'use strict';

    angular
        .module('svt')
        .service('questionSvc', questionSvc);

    questionSvc.$inject = ['pageSvc', 'questionDataSvc'];

    function questionSvc(pageSvc, questionDataSvc) {
        var questionsInPage = {};
        var isShowQuestionEditor = { value: {} };
        var isShowQuestionCreator = { value: {} };

        var questionType = {
            OpenEndedTextQuestionDefinition: 'OpenEndedTextQuestionDefinition',
            SingleChoiceQuestionDefinition: 'SingleChoiceQuestionDefinition',
            MultipleChoiceQuestionDefinition: 'MultipleChoiceQuestionDefinition',
            InformationDefinition: 'InformationDefinition',
            NumericQuestionDefinition: 'NumericQuestionDefinition'
        };

        var questionTypes = [
            { code: questionType.OpenEndedTextQuestionDefinition, name: 'Text' },
            { code: questionType.SingleChoiceQuestionDefinition, name: 'Single Choice' },
            { code: questionType.MultipleChoiceQuestionDefinition, name: 'Multiple Choice' },
            { code: questionType.InformationDefinition, name: 'Information' },
            { code: questionType.NumericQuestionDefinition, name: 'Numeric' }
        ];

        var modes = {
            text: { name: questionType.OpenEndedTextQuestionDefinition, status: false },
            singleChoice: { name: questionType.SingleChoiceQuestionDefinition, status: false },
            multipleChoice: { name: questionType.MultipleChoiceQuestionDefinition, status: false },
            information: { name: questionType.InformationDefinition, status: false },
            numeric: { name: questionType.NumericQuestionDefinition, status: false }
        };

        var surveyId = 0;

        var service = {
            getModes: getModes,
            getQuestionTypes: getQuestionTypes,
            updateStatusModes: updateStatusModes,
            hideOldQuestionEditor: hideOldQuestionEditor,
            hideOldQuestionCreator: hideOldQuestionCreator,
            getAllById: getAllById,
            getTotalQuestion: getTotalQuestion,
            getCurrentPosition: getCurrentPosition,
            addNew: addNew,
            updateById: updateById,
            deleteById: deleteById,
            getIsShowQuestionEditor: getIsShowQuestionEditor,
            toggleIsShowQuestionEditor: toggleIsShowQuestionEditor,
            getIsShowQuestionCreator: getIsShowQuestionCreator,
            toggleIsShowQuestionCreator: toggleIsShowQuestionCreator,
            getNumberCurrentQuestionOfEditor: getNumberCurrentQuestionOfEditor,
            getNameQuestionType: getNameQuestionType,
            getCodeQuestionType: getCodeQuestionType,
            moveToAnotherPage: moveToAnotherPage,
            moveInsidePage: moveInsidePage,
            getInitLanguageString: getInitLanguageString,
            setSelectedSurveyId: setSelectedSurveyId,
            getSelectedSurveyId: getSelectedSurveyId,
            getAnswers: getAnswers,
            isSingleChoice: isSingleChoice,
            isMultipleChoice: isMultipleChoice,
            populateAnswerAlternatives: populateAnswerAlternatives,
            getDefaultAdvanceSettings: getDefaultAdvanceSettings
        };

        return service;

        function getModes() {
            return modes;
        }

        function getQuestionTypes() {
            return questionTypes;
        }
        
        function updateStatusModes(nameModes) {
            for (var index in modes) {
                if (modes.hasOwnProperty(index))
                    modes[index].status = modes[index].name === nameModes ? true : false;
            }
        }

        function hideOldQuestionEditor() {
            for (var index in isShowQuestionEditor.value) {
                if (isShowQuestionEditor.value.hasOwnProperty(index))
                    isShowQuestionEditor.value[index] = false;
            }
        }

        function hideOldQuestionCreator() {
            for (var index in isShowQuestionCreator.value) {
                if (isShowQuestionCreator.value.hasOwnProperty(index))
                    isShowQuestionCreator.value[index] = false;
            }
        }

        function getAllById(surveyId, pageId) {
            questionDataSvc.getAllById(surveyId, pageId)
                .$promise.then(function (response) {
                    questionsInPage[pageId] = { data: [] };
                    for (var questionIndex in response) {
                        var question = response[questionIndex];
                        if (question.PageDefinitionId === pageId) {
                            if (question.$type.indexOf(questionType.OpenEndedTextQuestionDefinition) > -1) {
                                question.type = questionType.OpenEndedTextQuestionDefinition;
                            } else if (question.$type.indexOf(questionType.SingleChoiceQuestionDefinition) > -1) {
                                question.type = questionType.SingleChoiceQuestionDefinition;
                                question.answers = getAnswers(question);
                            } else if (question.$type.indexOf(questionType.MultipleChoiceQuestionDefinition) > -1) {
                                question.type = questionType.MultipleChoiceQuestionDefinition;
                                question.answers = getAnswers(question);
                            } else if (question.$type.indexOf(questionType.InformationDefinition) > -1) {
                                question.type = questionType.InformationDefinition;
                            } else if (question.$type.indexOf(questionType.NumericQuestionDefinition) > -1) {
                                question.type = questionType.NumericQuestionDefinition;
                            }
                            questionsInPage[pageId].data.push(question);
                        }
                    }
                });
            return questionsInPage;
        }

        function isSingleChoice(questionTypeSelected) {
            return questionTypeSelected === questionTypes[1].code;
        }

        function isMultipleChoice(questionTypeSelected) {
            return questionTypeSelected === questionTypes[2].code;
        }

        function getAnswers(question) {
            var answers = [];
            if (question.OptionList && question.OptionList.Options) {
                for (var index in question.OptionList.Options) {
                    answers.push(
                        {
                            id: question.OptionList.Options[index].Text.Items[0].Id,
                            value: question.OptionList.Options[index].Text.Items[0].Text,
                        }
                    );
                }
            }
            return answers;
        }

        function getTotalQuestion() {
            var total = 0;
            for (var index in questionsInPage) {
                if (questionsInPage.hasOwnProperty(index))
                    total += questionsInPage[index].data.length;
            }
            return total;
        }

        function getCurrentPosition(pageId) {
            var position = 0;
            for (var index in questionsInPage[pageId].data) {
                if (questionsInPage[pageId].data.hasOwnProperty(index)) {
                    position = questionsInPage[pageId].data[index].Position;
                }
            }
            return position;
        }

        function addNew(question) {
            return questionDataSvc.addNew(question);
        }

        function updateById(question) {
            return questionDataSvc.updateById(question);
        }

        function deleteById(question) {
            return questionDataSvc.deleteById(question);
        }

        function getIsShowQuestionEditor() {
            return isShowQuestionEditor;
        }

        function toggleIsShowQuestionEditor(index) {
            isShowQuestionEditor.value[index] = !isShowQuestionEditor.value[index];
        }

        function getIsShowQuestionCreator() {
            return isShowQuestionCreator;
        }

        function toggleIsShowQuestionCreator(index) {
            isShowQuestionCreator.value[index] = !isShowQuestionCreator.value[index];
        }

        function getNumberCurrentQuestionOfEditor(item, index) {
            var numberCurrentQuestion;
            var pages = pageSvc.getAll();
            var pageIndexOfItem = pageSvc.findPageIndexById(pages, item.PageDefinitionId);
            if (pageIndexOfItem === 0) {
                numberCurrentQuestion = index + 1;
            } else {
                var numberCurrentTemp = 0;
                for (var i = pageIndexOfItem - 1; i >= 0; i--) {
                    numberCurrentTemp += questionsInPage[pages[i].Id].data.length;
                }
                numberCurrentQuestion = numberCurrentTemp + index + 1;
            }
            return numberCurrentQuestion;
        }

        function getNameQuestionType(type) {
            for (var index in questionTypes) {
                if (questionTypes[index].code === type) {
                    return questionTypes[index].name;
                }
            }
        }

        function getCodeQuestionType(type) {
            if (typeof (type) === 'undefined') return null;
            for (var index in questionTypes) {
                if (type.indexOf(questionTypes[index].code) > -1) {
                    return questionTypes[index].code;
                }
            }
        }

        function moveToAnotherPage(movingQuestion) {
            return questionDataSvc.moveToAnotherPage(movingQuestion);
        }

        function moveInsidePage(movingQuestion) {
            return questionDataSvc.moveInsidePage(movingQuestion);
        }

        function getInitLanguageString() {
            return {
                $type: "LanguageString",
                Id: 0,
                SurveyId: 0,
                Items: [{
                    $type: "LanguageStringItem",
                    Id: 0,
                    Language: 9,
                    Text: ''
                }]
            };
        }

        function setSelectedSurveyId(selectedSurveyId) {
            surveyId = selectedSurveyId;
        }

        function getSelectedSurveyId() {
            return surveyId;
        }

        function populateAnswerAlternatives(surveyId, answers) {
            var optionLists = [];
            var code = 0;
            for (var index in answers) {
                code = code + 1;
                var option = angular.copy(getInitLanguageString());
                option.SurveyId = surveyId;
                option.Items[0].Text = answers[index].value;
                optionLists.push({
                    $type: "Option",
                    Id: 0,
                    ListId: 0,
                    Code: code,
                    Text: option
                });
            }
            return optionLists;
        }

        function getDefaultAdvanceSettings() {
            return {
                Name: '',
                RequiredValidation: { IsRequired: false },
                IsFixedPosition: false,
                OrderType: 0,
                IsShowOrderType: false
            };
        }
    }
})();