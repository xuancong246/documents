﻿(function () {
    'use strict';

    angular
        .module('svt')
        .controller('singleChoiceQuestionCtrl', singleChoiceQuestionCtrl);

    singleChoiceQuestionCtrl.$inject = [
        '$timeout'];

    function singleChoiceQuestionCtrl(
        $timeout) {
        /* jshint -W040 */
        var vm = this;

        vm.addOption = addOption;
        vm.removeOption = removeOption;
        vm.answerSingleChoice = [
            { id: 'Opt-1', value: 'Option 1' }
        ];

        vm.sortableOptionsSingleChoice = {
            itemMoved: function () { },
            orderChanged: function () { },
            containment: 'body',
            accept: function (sourceItemHandleScope) {
                return (sourceItemHandleScope.itemScope.answer) ? true : false;
            }
        };

        function addOption() {
            var id = Object.keys(vm.answerSingleChoice).length + 1;
            var answer = {
                id: 'Opt-' + id,
                value: 'Option ' + id
            };
            vm.answerSingleChoice.push(answer);
            $timeout(function () {
                document.getElementById(answer.id).select();
            }, 0);
        }

        function removeOption(index) {
            vm.answerSingleChoice.splice(index, 1);
        }
    }
})();