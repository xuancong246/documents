﻿(function () {
    'use strict';

    angular
        .module('svt')
        .directive('questionAdvanceSettings', questionAdvanceSettings);

    function questionAdvanceSettings() {
        var directive = {
            restrict: 'E',
            scope: {
                settings: '='
            },
            templateUrl: 'survey/question/question-advance-settings.html',
            controller: 'questionAdvanceSettingsCtrl',
            controllerAs: 'vm'
        };
        return directive;
    }
})();