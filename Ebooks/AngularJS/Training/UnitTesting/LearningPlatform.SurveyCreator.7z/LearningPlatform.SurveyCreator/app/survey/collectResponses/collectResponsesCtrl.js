﻿(function () {
    'use strict';

    angular
        .module('svt')
        .controller('collectResponsesCtrl', collectResponsesCtrl);

    collectResponsesCtrl.$inject = ['$scope', '$routeParams', 'respondentDataSvc', '$http', 'host', 'ModalService', 'usSpinnerService'];

    function collectResponsesCtrl($scope, $routeParams, respondentDataSvc, $http, host, ModalService, usSpinnerService) {
        /* jshint -W040 */
        var vm = this;

        vm.uploadedFileName = '';
        vm.isSpinnerActive = false;
        vm.emailMessage = {
            emailAddress: '',
            subject: 'Survey Invitation',
            content: 'We\'re conducting a survey and your input would be appreciated. Click the button below to start the survey. Thank you for your participation!'
        };
        vm.showUploadEditor = showUploadEditor;
        vm.sendEmail = sendEmail;
        vm.testSendEmail = testSendEmail;
        vm.hasUploadedFile = hasUploadedFile;
        vm.clearContact = clearContact;

        function showUploadEditor() {
            if (isSpinnerActive()) {
                return;
            }
            reset();
            showImportForm();
        }
        
        function setUploadedFileName(name) {
            vm.uploadedFileName = name;
        }

        function isSpinnerActive() {
            return vm.isSpinnerActive;
        }
        function setSpinnerActive(status) {
            vm.isSpinnerActive = status;
        }

        function spinnerShow() {
            setSpinnerActive(true);
            usSpinnerService.spin('spinnerSend');
        }

        function spinnerHide() {
            setSpinnerActive(false);
            usSpinnerService.stop('spinnerSend');
        }

        function showImportForm() {
            ModalService.showModal({
                templateUrl: 'survey/collectResponses/uploadRespondentDialog/uploadRespondentDialog.html',
                controller: 'uploadRespondentDialogCtrl',
                inputs: {
                    surveyId: $routeParams.id,
                    message: ''
                }
            }).then(function (modal) {
                modal.element.modal();
                modal.close.then(function (result) {
                    if (result.status) {
                        vm.uploadedFileName = result.uploadedFileName;
                    }
                });
            });
        }

        function validate(isTestSend) {
            if (isTestSend) {
                if (vm.emailMessage.emailAddress === '') {
                    toastr.warning('Please enter email address.');
                    return false;
                }
            } else {
                if (vm.emailMessage.emailAddress === '' && vm.uploadedFileName === '') {
                    toastr.warning('Please enter email address or import contacts.');
                    return false;
                }
            }
            if (vm.emailMessage.emailAddress !== '' && !validateEmail(vm.emailMessage.emailAddress)) {
                toastr.warning('Invalid email address.');
                return false;
            }
            if (vm.emailMessage.subject === '') {
                toastr.warning('Please enter subject.');
                return false;
            }
            if (vm.emailMessage.content === '') {
                toastr.warning('Please enter content.');
                return false;
            }
            return true;
        }

        function validateEmail(email) {
            var re = /^([\w+-.%]+@[\w-.]+\.[A-Za-z]{2,4};?)+$/i;
            return re.test(email);
        }

       function sendEmail() {
            if (isSpinnerActive()) {
                return;
            }
            if (!validate(false)) {
                return;
            }
            spinnerShow();
            respondentDataSvc.sendEmail($routeParams.id, getSendRespondentForm(vm.emailMessage, vm.uploadedFileName)).$promise.then(
                function (response) {
                    spinnerHide();
                    toastr.success('Send emails was successfully.');
                },
                function () {
                    spinnerHide();
                    toastr.error('Send emails was not successfully.');
                }
            );
            reset();
        }

       function testSendEmail() {
            if (isSpinnerActive()) {
                return;
            }
            if (!validate(true)) {
                return;
            }
            spinnerShow();
            respondentDataSvc.testSendEmail($routeParams.id, getSendRespondentForm(vm.emailMessage, '')).$promise.then(
               function (response) {
                   spinnerHide();
                   toastr.success('Test send was successfully.');
               },
               function (error) {
                   spinnerHide();
                   toastr.error(error.data.Message, 'Test send was not successfully.');
               }
           );
        }

        function getUploadRespondentForm(respondentFileName) {
            return {
                type$: "LearningPlatform.Models.UploadRespondentForm, LearningPlatform",
                FileName: respondentFileName
            };
        }

        function getSendRespondentForm(emailMessage, respondentFileName) {
            return {
                type$: "LearningPlatform.Models.SendRespondentForm, LearningPlatform",
                RespondentFileName: respondentFileName,
                EmailAddress: emailMessage.emailAddress,
                Subject: emailMessage.subject,
                Content: emailMessage.content
            };
        }

        function reset() {
            vm.uploadedFileName = '';
        }

        function hasUploadedFile () {
            return vm.uploadedFileName !== '';
        }

        function clearContact() {
            reset();
        }
    }
})();