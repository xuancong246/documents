﻿(function () {
    'use strict';
    describe('Testing questionSvc service', function() {
        var pageSvc, questionDataSvc;
        var questionMock = {
            OptionList: {
                Options: [{
                        Text: {
                            Items: [{
                                    Id: 65,
                                    Text: "Option 1"
                            }]
                        }
                }]
            }
        };
        var responseMock = [
            {
                $type: "LearningPlatform.Domain.SurveyDesign.MultipleChoiceQuestionDefinition, LearningPlatform.Domain",
                AlternativeList: {
                    $type: "LearningPlatform.Domain.SurveyDesign.AlternativeList, LearningPlatform.Domain",
                    Alternatives: Array[1],
                    Id: 11,
                    Name: null,
                    SurveyId: 3
                },
                Heading: Object,
                Id: 20,
                Name: "Question_318171426786",
                OrderType: 0,
                PageDefinitionId: 12,
                ParentQuestionId: null,
                Position: 1,
                Seed: 0,
                SurveyId: 3,
                Text: {},
                answers: Array[1],
                type: "MultipleChoiceQuestionDefinition"
            }
        ];

        beforeEach(function () {
            module('svt');
            module(function($provide) {
                pageSvc = jasmine.createSpyObj('pageSvc', ['getAll', 'findPageIndexById', 'getAllSurveys']);
                questionDataSvc = jasmine.createSpyObj('questionDataSvc', [
                    'getAllById', 'addNew', 'updateById', 'deleteById', 'moveToAnotherPage', 'moveInsidePage'
                ]);
                
                $provide.value('pageSvc', pageSvc);
                $provide.value('questionDataSvc', questionDataSvc);
            });
        });

        describe('Testing updateStatusModes function', function() {
            it('should change Status properties', inject(function(questionSvc) {
                var nameModes = 'OpenEndedTextQuestionDefinition';
                questionSvc.updateStatusModes(nameModes);

                expect(questionSvc.getModes().text.status).toEqual(true);
            }));
        });

        describe('Testing hideOldQuestionEditor function', function() {
            it('should change isShowQuestionEditor value', inject(function(questionSvc) {
                questionSvc.hideOldQuestionEditor();
                var isShowQuestionEditor = questionSvc.getIsShowQuestionEditor();

                for (var index in isShowQuestionEditor.value) {
                    if (isShowQuestionEditor.value.hasOwnProperty(index))
                        expect(isShowQuestionEditor.value[index]).ToEqual(false);
                }
            }));
        });

        describe('Testing hideOldQuestionCreator function', function() {
            it('should change isShowQuestionCreator value', inject(function(questionSvc) {
                questionSvc.hideOldQuestionCreator();
                var isShowQuestionCreator = questionSvc.getIsShowQuestionCreator();

                for (var index in isShowQuestionCreator.value) {
                    if (isShowQuestionCreator.value.hasOwnProperty(index))
                        expect(isShowQuestionCreator.value[index]).ToEqual(false);
                }
            }));
        });

        describe('Testing getAllById function', function() {
            it('should should return all question based on survey ID and page ID', inject(function (questionSvc,$q) {
                questionDataSvc.getAllById.and.returnValue({ $promise: $q.when(responseMock) });
                var questionsInPage = questionSvc.getAllById(3, 12);

                expect(questionsInPage[12].data).toEqual(responseMock).because('the case is failed because the promise can be processed after return command');
            }));
        });

        describe('Testing getAnswers function', function() {
            it('should return the answer list of the question', inject(function(questionSvc) {
                var answer = questionSvc.getAnswers(questionMock);

                expect(answer).toEqual([{ id: 65, value: 'Option 1' }]);
            }));
        });

        describe('Testing addNew function', function() {
            it('should call to addNew function on questionDataSvc', inject(function(questionSvc) {
                questionSvc.addNew(questionMock);

                expect(questionDataSvc.addNew).toHaveBeenCalledWith(questionMock);
            }));
        });

        describe('Testing updateById function', function () {
            it('should call to updateById function on questionDataSvc', inject(function (questionSvc) {
                questionSvc.updateById(questionMock);

                expect(questionDataSvc.updateById).toHaveBeenCalledWith(questionMock);
            }));
        });
        
        describe('Testing addNew function', function () {
            it('should call to addNew function on questionDataSvc', inject(function (questionSvc) {
                questionSvc.deleteById(questionMock);

                expect(questionDataSvc.deleteById).toHaveBeenCalledWith(questionMock);
               
            }));
        });

        describe('Testing moveToAnotherPage function', function () {
            it('should call to moveToAnotherPage function on questionDataSvc', inject(function (questionSvc) {
                questionSvc.moveToAnotherPage(questionMock);

                expect(questionDataSvc.moveToAnotherPage).toHaveBeenCalledWith(questionMock);
            }));
        });

        describe('Testing addNew function', function () {
            it('should call to addNew function on questionDataSvc', inject(function (questionSvc) {
                questionSvc.moveInsidePage(questionMock);

                expect(questionDataSvc.moveInsidePage).toHaveBeenCalledWith(questionMock);

            }));
        });

        describe('Testing getNumberCurrentQuestionOfEditor function', function () {
            it('should call to addNew function on questionDataSvc', inject(function (questionSvc) {
                var numberCurrentQuestion = questionSvc.getNumberCurrentQuestionOfEditor({}, 0);

                expect(numberCurrentQuestion).not.toBe(null);

            }));
        });

        describe('Testing getNameQuestionType function', function () {
            it('should return the Question type name', inject(function (questionSvc) {
                var result = questionSvc.getNameQuestionType('SingleChoiceQuestionDefinition');

                expect(result).toEqual('Single Choice');
            }));
        });

        describe('Testing getCodeQuestionType function', function () {
            it('should return the Question type code', inject(function (questionSvc) {
                var typeMock = "LearningPlatform.Domain.SurveyDesign.MultipleChoiceQuestionDefinition, LearningPlatform.Domain";
                var result = questionSvc.getCodeQuestionType(typeMock);

                expect(result).toEqual('MultipleChoiceQuestionDefinition');
            }));
        });
    });
})();