﻿(function() {
    'use strict';
    describe('Testing surveyDataSvc service', function() {
        var httpBackend,
            surveyDataSvc,
            hostMock = 'http://localhost:52071/api';

        beforeEach(function() {
            module('svt');
            inject(function($injector) {
                httpBackend = $injector.get('$httpBackend');
                surveyDataSvc = $injector.get('surveyDataSvc');
            });
        });

        describe('Testing count function', function () {
            it('should return the count of survey items', function() {
                var countFormMock = {
                    searchString: 'abc'
                };
                httpBackend.expectGET(hostMock + '/surveys/count?searchString=abc').respond({count: 10});
                var result = surveyDataSvc.count(countFormMock);
                httpBackend.flush();
                var expectedCount = 10;
                expect(result.count).toEqual(expectedCount);
            });
        });

        describe('Testing search function', function() {
            it('should return searching result', function() {
                var searchFormMock = {
                    searchString: 'abc',
                    paging: {
                        start: 1,
                        limit: 10
                    }
                };
                httpBackend.expectGET(hostMock + '/surveys/search?limit=10&searchString=abc&start=1').respond([{ id: 1, name: 'a' }, { id: 2, name: 'b' }]);
                var result = surveyDataSvc.search(searchFormMock);
                httpBackend.flush();
                var expectedResult = [{ id: 1, name: 'a' }, { id: 2, name: 'b' }];
                expect(angular.toJson(result)).toEqual(angular.toJson(expectedResult));
            });
        });

        describe('Testing deleteSurvey function', function() {
            it('should delete survey', function() {
                httpBackend.expectDELETE(hostMock + '/surveys/123/definition').respond({ result: true });
                var result = surveyDataSvc.deleteSurvey(123);
                httpBackend.flush();
                expect(angular.toJson(result)).toContain('result');
            });
        });

        describe('Testing getAllSurveys function', function() {
            it('should return all survey items', function() {
                httpBackend.expectGET(hostMock + '/surveys').respond([{ id: 1, name: 'a' }, { id: 2, name: 'b' }, { id: 3, name: 'c' }]);
                var result = surveyDataSvc.getAllSurveys();
                httpBackend.flush();
                var expectedResult = [{ id: 1, name: 'a' }, { id: 2, name: 'b' }, { id: 3, name: 'c' }];
                expect(angular.toJson(result)).toEqual(angular.toJson(expectedResult));
            });
        });

        afterEach(function() {
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();
        });
    });
})();