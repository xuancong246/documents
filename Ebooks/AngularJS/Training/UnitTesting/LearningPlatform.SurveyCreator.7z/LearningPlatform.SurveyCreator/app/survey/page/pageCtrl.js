﻿(function () {
    'use strict';

    angular
        .module('svt')
        .controller('pageCtrl', pageCtrl);

    pageCtrl.$inject = ['$scope',
                        '$route',   
                        'ModalService',
                        'pageSvc',
                        'questionSvc',
                        'constantSvc'];

    function pageCtrl($scope,
                      $route,
                      ModalService,
                      pageSvc,
                      questionSvc,
                      constantSvc) {
        /* jshint -W040 */
        var vm = this;

        vm.pageIndex = $scope.index;
        vm.pages = $scope.$parent.$parent.modelValue;
        vm.totalPage = vm.pages.length;
        vm.modes = questionSvc.getModes();
        vm.isShowQuestionEditor = questionSvc.getIsShowQuestionEditor();
        vm.isShowQuestionCreator = questionSvc.getIsShowQuestionCreator();
        vm.isShowPageEditor = pageSvc.getIsShowPageEditor();
        vm.currentPage = vm.pages[vm.pageIndex];
        vm.questionsInPage = questionSvc.getAllById(vm.currentPage.SurveyId, vm.currentPage.Id);
        vm.generalConstant = {
            MIN_TOTAL_PAGE: 2,
            MIN_TOTAL_QUESTION_IN_PAGE: 0
        };
        vm.page = angular.copy(vm.currentPage);
        vm.navigationButtonSettings = [
            { code: 0, name: 'Default' },
            { code: 1, name: 'ForwardOnly' },
            { code: 2, name: 'None' }
        ];
        vm.questionOrders = [
             { code: 0, name: 'In Order' },
             { code: 1, name: 'Randomized' },
             { code: 2, name: 'Flipped' },
             { code: 3, name: 'Rotated' }
        ];
        vm.isThankYouPage = pageSvc.isThankYouPage(vm.currentPage);

        vm.sortableOptionsQuestion = {
            itemMoved: function (event) {
                moveQuestion(event);
            },
            orderChanged: function (event) {
                moveQuestion(event);
            },
            containment: 'body',
            accept: function (sourceItemHandleScope) {
                questionSvc.hideOldQuestionEditor();
                questionSvc.hideOldQuestionCreator();
                pageSvc.hidePageEditor();
                return (sourceItemHandleScope.itemScope.question && !sourceItemHandleScope.itemScope.answer) ? true : false;
            }
        };

        vm.showQuestionEditor = showQuestionEditor;
        vm.showQuestionCreator = showQuestionCreator;
        vm.showPageEditor = showPageEditor;
        vm.hidePageEditor = hidePageEditor;
        vm.onAddPage = onAddPage;
        vm.onDeletePage = onDeletePage;
        vm.onEditPage = onEditPage;

        function moveQuestion(event) {
            var sourcePage = event.source.sortableScope.$parent.pageCtrl.currentPage;
            var destPage = event.dest.sortableScope.$parent.pageCtrl.currentPage;
            if (pageSvc.isThankYouPage(sourcePage) || pageSvc.isThankYouPage(destPage)) {
                toastr.warning('Cannot move question in thank you page');
                $route.reload();
                return;
            }

            var destinationPageId = event.dest.sortableScope.$parent.pageCtrl.currentPage.Id;
            var movingQuestion = event.source.itemScope.question;
            var newIndexPosition = event.dest.index;
            var oldIndexPosition = event.source.index;
            var question = {
                QuestionId: movingQuestion.Id,
                DeparturePageId: movingQuestion.PageDefinitionId,
                DestinationPageId: destinationPageId,
                SurveyId: movingQuestion.SurveyId,
                NewIndexPosition: newIndexPosition,
                OldIndexPosition: oldIndexPosition
            };
            if (destinationPageId !== movingQuestion.PageDefinitionId) {
                questionSvc.moveToAnotherPage(question).$promise.then(function (response) {
                    if (!response.Status) return;
                    questionSvc.getAllById(question.SurveyId, destinationPageId);
                    questionSvc.getAllById(question.SurveyId, movingQuestion.PageDefinitionId);
                });
            } else {
                questionSvc.moveInsidePage(question).$promise.then(function (response) {
                    if (!response.Status) return;
                    questionSvc.getAllById(question.SurveyId, destinationPageId);
                });
            }
        }

        function showQuestionEditor(question, index) {
            questionSvc.hideOldQuestionEditor();
            questionSvc.hideOldQuestionCreator();
            pageSvc.hidePageEditor();
            $scope.questionToEdit = question;
            var type = questionSvc.getCodeQuestionType(question.$type);
            questionSvc.updateStatusModes(type);
            vm.numberTotalQuestionOfEditor = questionSvc.getTotalQuestion();
            vm.numberCurrentQuestionOfEditor = questionSvc.getNumberCurrentQuestionOfEditor(question, index);
            questionSvc.toggleIsShowQuestionEditor(question.Id);
        }

        function showQuestionCreator(type) {
            vm.numberTotalQuestionInCreator = questionSvc.getTotalQuestion() + 1;
            questionSvc.hideOldQuestionEditor();
            questionSvc.hideOldQuestionCreator();
            pageSvc.hidePageEditor();
            questionSvc.updateStatusModes(type);
            $scope.createQuestionCtrl.questionTypeSelected = type;
            $scope.createQuestionCtrl.questionType = questionSvc.getNameQuestionType(type);
            $scope.createQuestionCtrl.resetAdvanceSetting();
            questionSvc.toggleIsShowQuestionCreator(vm.currentPage.Id);
        }

        function showPageEditor(id) {
            pageSvc.setIdToShowPageEditor(id);
            pageSvc.hidePageEditor();
            questionSvc.hideOldQuestionEditor();
            questionSvc.hideOldQuestionCreator();
            pageSvc.toggleIsShowPageEditor();
        }

        function onAddPage() {
            pageSvc.addPage(vm.pageIndex, vm.currentPage.SurveyId, vm.currentPage.ParentId).$promise.then(function (response) {
                if (!response.Status) {
                    toastr.error('Create page was not successfully.');
                    return;
                }
                toastr.success('Create page was successfully.');
                pageSvc.getAllBySurveyId(vm.currentPage.SurveyId);
            });
        }

        function onDeletePage(event) {
            event.stopPropagation();
            vm.totalQuestionInPage = vm.questionsInPage[vm.currentPage.Id];
            if (vm.totalPage.value <= vm.generalConstant.MIN_TOTAL_PAGE) return;
            if (vm.totalQuestionInPage <= vm.generalConstant.MIN_TOTAL_QUESTION_IN_PAGE) {
                pageSvc.deletePage(vm.currentPage).$promise.then(function (response) {
                    if (!response.Status) return;
                    pageSvc.getAllBySurveyId(vm.currentPage.SurveyId);
                });
            } else {
                var confirmMessage = constantSvc.messages.deletePage;
                ModalService.showModal({
                    templateUrl: 'survey/common/deleteDialog/deleteDialog.html',
                    controller: 'deleteDialogCtrl',
                    inputs: {
                        message: confirmMessage
                    }
                }).then(function (modal) {
                    modal.element.modal();
                    modal.close.then(function (result) {
                        if (result) {
                            pageSvc.deletePage(vm.currentPage).$promise.then(function (response) {
                                if (!response.Status) {
                                    toastr.error('Delete page was not successfully.');
                                    return;
                                }
                                toastr.success('Delete page was successfully.');
                                pageSvc.getAllBySurveyId(vm.currentPage.SurveyId);
                            });
                        }
                    });
                });
            }
        }

        function onEditPage() {
            vm.currentPage.Name = vm.page.Name;
            vm.currentPage.Description = vm.page.Description;
            vm.currentPage.NavigationButtonSettings = vm.page.NavigationButtonSettings;
            vm.currentPage.IsFixedPosition = vm.page.IsFixedPosition;
            vm.currentPage.OrderType = vm.page.OrderType;

            pageSvc.updatePage(vm.currentPage).$promise.then(function (response) {
                if (!response.Status) {
                    toastr.error('Update page was not successfully.');
                    return;
                }
                toastr.success('Update page was successfully.');
            });
            pageSvc.hidePageEditor();
        }

        function hidePageEditor() {
            pageSvc.hidePageEditor();
        }
    }
})();
