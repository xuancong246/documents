﻿(function () {
    'use strict';

    angular
        .module('svt')
        .controller('testSurveyCtrl', testSurveyCtrl);

    testSurveyCtrl.$inject = ['$routeParams', '$sce', 'constantSvc'];

    function testSurveyCtrl($routeParams, $sce, constantSvc) {
        /* jshint -W040 */
        var vm = this;
        vm.surveyId = $routeParams.id;
        vm.url = $sce.trustAsResourceUrl(constantSvc.url.testUrl + $routeParams.id + '?v=' + new Date().getTime());
    }
})();