﻿(function () {
    'use strict';

    angular
        .module('svt')
        .directive('textQuestion', textPage);

    function textPage() {
        var directive = {
            restrict: 'E',
            scope: {
                question: '='
            },
            templateUrl: 'app/survey/question/types/text/text-question.html'
        };

        return directive;
    }
})();