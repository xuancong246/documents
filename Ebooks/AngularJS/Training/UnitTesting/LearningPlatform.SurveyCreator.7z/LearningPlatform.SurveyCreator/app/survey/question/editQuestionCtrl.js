﻿(function () {
    angular
        .module('svt')
        .controller('editQuestionCtrl', editQuestionCtrl);

    editQuestionCtrl.$inject = [
        '$scope',
        'questionSvc',
        'ModalService',
        'constantSvc'];

    function editQuestionCtrl(
        $scope,
        questionSvc,
        ModalService,
        constantSvc) {
        var vm = this;
        var generalConstant = {
            TEXT: 'text',
            SINGLE_CHOICE: 'singleChoice',
            PAGE: 'Page',
            VALID_LENGTH: 0
        };

        vm.question = [];
        vm.questionTypes = questionSvc.getQuestionTypes();
        vm.questionTypeSelected = '';
        vm.questionType = '';
        vm.modes = questionSvc.getModes();
        vm.settings = questionSvc.getDefaultAdvanceSettings();

        vm.cancelEditQuestion = cancelEditQuestion;
        vm.doneEditQuestion = doneEditQuestion;
        vm.removeQuestion = removeQuestion;
        vm.selectQuestionType = selectQuestionType;

        init();

        function init() {
            $scope.$watch('questionToEdit', function (newVal) {
                if (typeof (newVal) === 'undefined') {
                    return;
                }
                vm.question = angular.copy(newVal);
                vm.questionTypeSelected = questionSvc.getCodeQuestionType(vm.question.$type);
                vm.questionType = questionSvc.getNameQuestionType(vm.questionTypeSelected);

                setAdvanceSetingsFromQuestion(vm.question);
                if (questionSvc.isSingleChoice(vm.questionTypeSelected) || questionSvc.isMultipleChoice(vm.questionTypeSelected)) {
                    newVal.answers = questionSvc.getAnswers(vm.question);
                }

                if (typeof (newVal.answers) === 'undefined') return;
                if (newVal.answers.length < generalConstant.VALID_LENGTH) return;
                
                if (questionSvc.isSingleChoice(vm.questionTypeSelected)) {
                    $scope.singleChoiceQuestionCtrl.answerSingleChoice = angular.copy(newVal.answers);
                } else if (questionSvc.isMultipleChoice(vm.questionTypeSelected)) {
                    $scope.multipleChoiceQuestionCtrl.answerMultipleChoice = angular.copy(newVal.answers);
                }
            });
        }

        function setAdvanceSetingsFromQuestion(question) {
            var requiredValidation = getRequiredValidation(question.Validations);
            var showOrderType = questionSvc.isSingleChoice(vm.questionTypeSelected) || questionSvc.isMultipleChoice(vm.questionTypeSelected);
            vm.settings = {
                Name: angular.copy(question.Name),
                RequiredValidation: requiredValidation,
                IsFixedPosition: angular.copy(question.IsFixedPosition),
                IsShowOrderType: showOrderType,
                OrderType: angular.copy(question.OrderType)
            };
        }

        function getRequiredValidation(validations) {
            var requiredValidation = {
                IsRequired: false
            };
            if (validations !== null && validations.length > 0) {
                for (var i = 0; i < validations.length; i++)
                    if (validations[i].$type === 'RequiredValidation') {
                        requiredValidation = angular.copy(validations[i]);
                        requiredValidation.IsRequired = true;
                        break;
                    }
            }
            return requiredValidation;
        }

        function selectQuestionType() {
            vm.questionType = questionSvc.getNameQuestionType(vm.questionTypeSelected);
            questionSvc.updateStatusModes(vm.questionTypeSelected);
            resetSelectQuestionType();
        }

        function resetSelectQuestionType() {
            if ($scope.singleChoiceQuestionCtrl) {
                $scope.singleChoiceQuestionCtrl.answerSingleChoice = [
                    { id: 'Opt-1', value: 'Option 1' }
                ];
            }
            if ($scope.multipleChoiceQuestionCtrl) {
                $scope.multipleChoiceQuestionCtrl.answerMultipleChoice = [
	               { id: 'Opt-1', value: 'Option 1' }
                ];
            }
        }

        function cancelEditQuestion() {
            resetSelectQuestionType();
            $scope.singleChoiceQuestionCtrl.answerSingleChoice = vm.question.answers;
            vm.questionTypeSelected = vm.question.type;
            questionSvc.toggleIsShowQuestionEditor(vm.question.Id);
        }

        function doneEditQuestion() {
            if (vm.question.Heading.Items[0].Text.trim() === '') {
                toastr.warning('Question title is required.');
                return;
            }
            if (questionSvc.isSingleChoice(vm.questionTypeSelected) || questionSvc.isMultipleChoice(vm.questionTypeSelected)) {
                var answers = questionSvc.isSingleChoice(vm.questionTypeSelected) ? $scope.singleChoiceQuestionCtrl.answerSingleChoice : $scope.multipleChoiceQuestionCtrl.answerMultipleChoice;
                vm.question.OptionList = {
                    $type: "OptionList",
                    Id: 0,
                    SurveyId: vm.question.SurveyId,
                    Options: questionSvc.populateAnswerAlternatives(vm.question.SurveyId, answers)
               };
            } else {
                vm.question.OptionList = null;
            }
            setAdvanceSetingsToQuestion();

            questionSvc.updateById(vm.question).$promise.then(function (response) {
                if (!response.Status) {
                    toastr.error('Update question was not successfully.');
                    return;
                }
                toastr.success('Update question was successfully.');
                questionSvc.toggleIsShowQuestionEditor(vm.question.Id);
                questionSvc.getAllById(vm.question.SurveyId, vm.question.PageDefinitionId);
                resetForm();
            });
        }

        function setAdvanceSetingsToQuestion() {
            vm.question.Name = vm.settings.Name;
            vm.question.IsFixedPosition = vm.settings.IsFixedPosition;
            if (questionSvc.isSingleChoice(vm.questionTypeSelected) || questionSvc.isMultipleChoice(vm.questionTypeSelected)) {
                vm.question.OrderType = vm.settings.OrderType;
            }
            handleRequiredValidation();
        }

        function handleRequiredValidation() {
            if (vm.settings.RequiredValidation.IsRequired) {
                vm.question.Validations.push(
                    {
                        $type: 'RequiredValidation',
                        Id: 0,
                        QuestionDefinitionId: vm.question.Id
                    }
                );
            } else {
                for (var index in vm.question.Validations) {
                    if (vm.question.Validations[index].$type === 'RequiredValidation') {
                        vm.question.Validations.splice(index, 1);
                        break;
                    }
                }
            }
        }

        function resetForm() {
            vm.question = {
                $type: '',
                Id: 0,
                OptionList: null,
                OrderType: 0,
                Seed: 0,
                IsInGrid: false,
                ParentQuestionId: null,
                PageDefinitionId: 0,
                Name: '',
                Heading: null,
                Text: null,
                SurveyId: 0,
                Position: 0,
                Validations: [],
                IsFixedPosition: false
            };
            resetSelectQuestionType();
        }

        function removeQuestion(event) {
            event.stopPropagation();
            var confirmMessage = constantSvc.messages.deleteQuestion;
            ModalService.showModal({
                templateUrl: 'survey/common/deleteDialog/deleteDialog.html',
                controller: 'deleteDialogCtrl',
                inputs: {
                    message: confirmMessage
                }
            }).then(function (modal) {
                modal.element.modal();
                modal.close.then(function (result) {
                    if (result) {
                        questionSvc.deleteById(vm.question).$promise.then(function (response) {
                            if (!response.Status) {
                                toastr.error('Delete question was not successfully.');
                                return;
                            }
                            toastr.success('Delete question was successfully.');
                            questionSvc.getAllById(vm.question.SurveyId, vm.question.PageDefinitionId);
                            resetForm();
                        });
                    }
                });
            });
        }
    }
})();