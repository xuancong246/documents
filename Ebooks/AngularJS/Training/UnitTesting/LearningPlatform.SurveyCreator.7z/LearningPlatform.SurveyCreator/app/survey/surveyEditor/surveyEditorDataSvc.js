﻿(function () {
    'use strict';

    angular
        .module('svt')
        .factory('surveyEditorDataSvc', surveyEditorDataSvc);

    surveyEditorDataSvc.$inject = ['$resource', 'host'];

    function surveyEditorDataSvc($resource, host) {
        var dataService = {
            getSurvey: getSurvey
        };
        return dataService;

        function getSurvey(surveyId) {
            return $resource(host + '/surveys/:surveyId/definition', { surveyId: '@surveyId' }, { 'getSurvey': { method: 'GET' } }).getSurvey({ surveyId: surveyId });
        }

    }
})();