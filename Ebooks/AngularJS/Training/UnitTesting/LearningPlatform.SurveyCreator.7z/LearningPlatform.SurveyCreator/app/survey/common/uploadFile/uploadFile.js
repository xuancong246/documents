﻿(function () {
    'use strict';

    angular
        .module('svt')
        .directive('uploadFile', uploadFile);

    function uploadFile() {
        return {
            restrict: "A",
            scope: {
                handler: '&'
            },
            link: function (scope, element) {
                element.change(function (event) {
                    scope.$apply(function () {
                        var params = { event: event, element: element };
                        scope.handler({ params: params });
                    });
                });
            }
        };
    }
})();