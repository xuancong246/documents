﻿(function () {
    'use strict';

    angular
        .module('svt')
        .controller('createQuestionCtrl', createQuestionCtrl);

    createQuestionCtrl.$inject = [
        '$scope',
        'questionSvc'];

    function createQuestionCtrl(
        $scope,
        questionSvc) {
        /* jshint -W040 */
        var vm = this;

        vm.pageId = $scope.pageCtrl.currentPage.Id;
        //TODO
        vm.question = {
            $type: "OpenEndedTextQuestionDefinition",
            Id: 0,
            OptionList: null,
            OrderType: 0,
            Seed: 0,
            IsInGrid: false,
            ParentQuestionId: null,
            PageDefinitionId: 0,
            Name: '',
            Heading: angular.copy(questionSvc.getInitLanguageString()),
            Text: angular.copy(questionSvc.getInitLanguageString()),
            SurveyId: questionSvc.getSelectedSurveyId(),
            Position: 0,
            Validations: [],
            IsFixedPosition: false
        };

        vm.questionTypes = questionSvc.getQuestionTypes();

        vm.questionTypeSelected = '';
        vm.questionType = '';
        vm.modes = questionSvc.getModes();
        vm.settings = questionSvc.getDefaultAdvanceSettings();

        vm.cancelAddQuestion = cancelAddQuestion;
        vm.doneCreateQuestion = doneCreateQuestion;
        vm.selectQuestionType = selectQuestionType;
        vm.resetAdvanceSetting = resetAdvanceSetting;

        function cancelAddQuestion() {
            questionSvc.toggleIsShowQuestionCreator(vm.pageId);
            resetForm();
        }

        function resetForm() {
            vm.question = {
                $type: '',
                Id: 0,
                OptionList: null,
                OrderType: 0,
                Seed: 0,
                IsInGrid: false,
                ParentQuestionId: null,
                PageDefinitionId: 0,
                Name: '',
                Heading: angular.copy(questionSvc.getInitLanguageString()),
                Text: angular.copy(questionSvc.getInitLanguageString()),
                SurveyId: questionSvc.getSelectedSurveyId(),
                Position: 0,
                Validations: [],
                IsFixedPosition: false
            };
            resetSelectQuestionType();
            vm.settings = questionSvc.getDefaultAdvanceSettings();
        }

        function doneCreateQuestion() {
            if (vm.question.Heading.Items[0].Text.trim() === '') {
                toastr.warning('Question title is required.');
                return;
            }

            vm.question.$type = vm.questionTypeSelected;
            vm.question.Position = questionSvc.getCurrentPosition(vm.pageId) + 1;
            vm.question.PageDefinitionId = vm.pageId;
            
            vm.question.Heading.SurveyId = vm.question.SurveyId;
            vm.question.Text.SurveyId = vm.question.SurveyId;
            if (questionSvc.isSingleChoice(vm.questionTypeSelected) || questionSvc.isMultipleChoice(vm.questionTypeSelected)) {
                var answers = questionSvc.isSingleChoice(vm.questionTypeSelected) ? $scope.singleChoiceQuestionCtrl.answerSingleChoice : $scope.multipleChoiceQuestionCtrl.answerMultipleChoice;
                vm.question.OptionList = {
                    $type: "OptionList",
                    Id: 0,
                    SurveyId: vm.question.SurveyId,
                    Options: questionSvc.populateAnswerAlternatives(vm.question.SurveyId, answers)
                };
            }
            setAdvanceSetingsToQuestion();

            questionSvc.addNew(vm.question).$promise.then(function (response) {
                if (!response.Status) {
                    toastr.error('Create question was not successfully.');
                    return;
                }
                toastr.success('Create question was successfully.');
                questionSvc.getAllById(vm.question.SurveyId, vm.question.PageDefinitionId);
                questionSvc.toggleIsShowQuestionCreator(vm.pageId);
                $scope.questionToEdit = vm.question;
                resetForm();
            });

        }

        function setAdvanceSetingsToQuestion() {
            vm.question.Name = vm.settings.Name;
            vm.question.IsFixedPosition = vm.settings.IsFixedPosition;
            if (questionSvc.isSingleChoice(vm.questionTypeSelected) || questionSvc.isMultipleChoice(vm.questionTypeSelected)) {
                vm.question.OrderType = vm.settings.OrderType;
            }
            if (vm.settings.RequiredValidation.IsRequired) {
                vm.question.Validations.push(
                    {
                        $type: 'RequiredValidation',
                        Id: 0,
                        QuestionDefinitionId: 0
                    }
                );
            }
        }

        function selectQuestionType() {
            vm.questionType = questionSvc.getNameQuestionType(vm.questionTypeSelected);
            questionSvc.updateStatusModes(vm.questionTypeSelected);
            resetSelectQuestionType();
            resetAdvanceSetting();
        }

        function resetSelectQuestionType() {
            if ($scope.singleChoiceQuestionCtrl) {
                $scope.singleChoiceQuestionCtrl.answerSingleChoice = [
                    { id: 'Opt-1', value: 'Option 1' }
                ];
            }
            if ($scope.multipleChoiceQuestionCtrl) {
                $scope.multipleChoiceQuestionCtrl.answerMultipleChoice = [
                    { id: 'Opt-1', value: 'Option 1' }
                ];
            }
        }

        function resetAdvanceSetting() {
            vm.settings = questionSvc.getDefaultAdvanceSettings();
            vm.settings.IsShowOrderType = questionSvc.isSingleChoice(vm.questionTypeSelected) || questionSvc.isMultipleChoice(vm.questionTypeSelected);
        }
    }
})();
