﻿(function () {
    'use strict';

    angular
        .module('svt')
        .controller('createSurveyDialogCtrl', createSurveyDialogCtrl);

    createSurveyDialogCtrl.$inject = ['$scope', '$element', 'createSurveyDataSvc', 'layoutDataSvc', 'close', 'editor'];

    function createSurveyDialogCtrl($scope, $element, createSurveyDataSvc, layoutDataSvc, close, editor) {

        $scope.layouts = { data: [] };
        $scope.Status = [
            { code: 'OPEN', name: 'Open' },
            { code: 'CLOSE', name: 'Close' },
            { code: 'PENDING', name: 'Pending' }
        ];
        $scope.PageOrders = [
             { code: 0, name: 'In Order' },
             { code: 1, name: 'Randomized' },
             { code: 2, name: 'Flipped' },
             { code: 3, name: 'Rotated' }
        ];
        $scope.editor = editor;
        $scope.save = save;

        function loadLayouts() {
            layoutDataSvc.getAllLayouts().$promise.then(function (response) {
                for (var index = 0; index < response.length; index++) {
                    $scope.layouts.data.push({
                        LayoutId: response[index].Id,
                        Name: response[index].Name,
                        Css: response[index].Css,
                        Templates: response[index].Templates
                    });
                }
            });
        }

        function init() {
            loadLayouts();
        }

        function save(result) {
            if (!result) {
                return;
            }

            if ($scope.editor.survey.Name === undefined || $scope.editor.survey.Name === '') {
                toastr.warning('Please enter required field.');
                return;
            }
            if ($scope.editor.survey.LayoutId === 0) {
                toastr.warning('Please choose a layout.');
                return;
            }

            if ($scope.editor.isAdd) {
                createSurveyDataSvc.addSurvey($scope.editor.survey).$promise.then(function (response) {
                    if (!response.Status) {
                        toastr.error('Create survey was not successfully.');
                        return;
                    }
                    toastr.success('Create survey was successfully.');
                    $element.modal('hide');
                    close({ status: true }, 500);
                });
            } else {
                createSurveyDataSvc.updateSurvey($scope.editor.survey).$promise.then(function (response) {
                    if (!response.Status) {
                        toastr.error('Update survey was not successfully.');
                        return;
                    }
                    $element.modal('hide');
                    close({ survey: $scope.editor.survey, status: true }, 500);
                    toastr.success('Update survey was successfully.');
                });
            }
        }

        init();
    }
})();