﻿(function () {
    'use strict';

    angular
        .module('svt')
        .directive('multipleChoiceQuestion', multipleChoiceQuestion);

    function multipleChoiceQuestion() {
        var directive = {
            restrict: 'E',
            scope: {
                multipleChoiceQuestion: '='
            },
            templateUrl: 'survey/question/types/multipleChoice/multiple-choice-question.html'
        };

        return directive;
    }
})();