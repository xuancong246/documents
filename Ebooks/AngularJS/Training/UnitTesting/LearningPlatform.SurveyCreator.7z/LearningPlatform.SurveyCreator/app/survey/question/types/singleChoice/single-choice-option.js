﻿(function () {
    'use strict';

    angular
        .module('svt')
        .directive('singleChoiceOption', singleChoiceOption);

    function singleChoiceOption() {
        var directive =  {
            restrict: 'E',
            templateUrl: 'survey/question/types/singleChoice/single-choice-option.html',
            require: '^?singleChoiceQuestionCtrl'
        };

        return directive;
    }
})();