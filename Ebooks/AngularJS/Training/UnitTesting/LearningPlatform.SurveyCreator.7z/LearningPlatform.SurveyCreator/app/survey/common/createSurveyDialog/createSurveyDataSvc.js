﻿(function () {
    'use strict';

    angular
        .module('svt')
        .factory('createSurveyDataSvc', surveyDataSvc);

    surveyDataSvc.$inject = ['$resource', 'host'];

    function surveyDataSvc($resource, host) {
        var dataService = {
            addSurvey: addSurvey,
            updateSurvey: updateSurvey,
        };

        return dataService;


        function addSurvey(survey) {
            return $resource(host + '/surveys/:surveyId/definition', { surveyId: '@surveyId' }, { 'addSurvey': { method: 'POST' } }).addSurvey({ surveyId: 0 }, JSON.stringify(survey));
        }

        function updateSurvey(survey) {
            return $resource(host + '/surveys/:surveyId/definition', { surveyId: '@surveyId' }, { 'updateSurvey': { method: 'PUT' } }).updateSurvey({ surveyId: survey.SurveyId }, JSON.stringify(survey));
        }
    }
})();