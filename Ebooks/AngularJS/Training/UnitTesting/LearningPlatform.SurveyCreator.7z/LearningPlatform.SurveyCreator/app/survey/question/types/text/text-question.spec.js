﻿describe("Testing Text Question directive", function () {
    var element, scope, $compile;
    beforeEach(module('svt','app/survey/question/types/text/text-question.html')); 

    beforeEach(inject(function (_$compile_, $rootScope) {
        scope = $rootScope;
        scope.question = {
            Heading: {
                Items: [
                {
                    Text: 'value 1'
                }]
            },
            Text: {
                Items: [
                {
                    Text: 'value 2'
                }]
            }
        };

        $compile = _$compile_;

        element = angular.element(
            '<text-question question="question" class="text-question"></text-question>');
        $compile(element)(scope);
        scope.$digest();
    }));

    it("should display the values", function () {
       var isoScope = element.isolateScope();
       expect(isoScope.question.Text.Items[0].Text).toEqual('value 2');
       expect(isoScope.question.Heading.Items[0].Text).toEqual('value 1');
    });
});