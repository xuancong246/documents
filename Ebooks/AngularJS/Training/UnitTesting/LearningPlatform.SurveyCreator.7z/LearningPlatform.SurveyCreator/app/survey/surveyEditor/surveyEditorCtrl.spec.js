﻿(function () {
    'use stric';
    describe('Testing surveyEditorCtrl controller', function () {
        var surveysCtrl, scope, pageSvc, questionSvc, surveyEditorDataSvc, ModalService;
        var surveyEditorMock = {
            isAdd: false,
            isShow: false,
            survey: {
                $type: "LearningPlatform.Models.SurveyForm, LearningPlatform",
                SurveyId: 0,
                Name: '',
                Status: '',
                LayoutId: 0,
                PageOrder: 0,
                SurveySettings: null
            }
        };
        var eventmock = {
            dest: {
                index: 4,
                sortableScope: {}
            },
            source: {
                index: 3,
                itemScope: {
                    page: {
                        id: 14,
                        SurveyID: '3'
                    }
                },
                sortableScope: {}
            }
        };
        beforeEach(function () {
            module('svt');
            
            var response = {
                $type: "LearningPlatform.Domain.SurveyDesign.Survey, LearningPlatform.Domain",
                CreatedDate: "Apr 09, 2015 03:52 PM",
                Id: 3,
                LayoutId: 1,
                Name: "abc",
                Status: "OPEN",
                TopFolder: {
                    OrderType: 0
                }
            };

            var responseModal = {
                $type: "LearningPlatform.Domain.SurveyDesign.Survey, LearningPlatform.Domain",
                CreatedDate: "Apr 09, 2015 03:52 PM",
                Id: 3,
                LayoutId: 1,
                Name: "abc",
                Status: "OPEN",
                TopFolder: {
                    OrderType: 0
                }
            };

            var movepageresponse = {
                Status: false
            };
            inject(function ($rootScope, $controller, $routeParams,$q) {
                scope = $rootScope.$new();
                
                pageSvc = jasmine.createSpyObj('pageSvc', ['getAllBySurveyId', 'movePage', 'isThankYouPage']);
                pageSvc.movePage.and.returnValue({ $promise: $q.when(movepageresponse) });
                pageSvc.isThankYouPage.and.callFake(function () { return false; });
                pageSvc.getAllBySurveyId.and.returnValue({ data: [{}, {}, {}] });
                questionSvc = jasmine.createSpyObj('questionSvc', ['setSelectedSurveyId']);

                surveyEditorDataSvc = jasmine.createSpyObj('surveyEditorDataSvc', ['getSurvey']);
                surveyEditorDataSvc.getSurvey.and.returnValue({ $promise: $q.when(response) });
                ModalService = jasmine.createSpyObj('ModalService', ['showModal']);
                ModalService.showModal.and.returnValue(responseModal);
                surveysEditorCtrl = $controller('surveyEditorCtrl', {
                    $scope: scope,
                    $routeParams: { id: '3' },
                    pageSvc: pageSvc, 
                    questionSvc: questionSvc  , 
                    surveyEditorDataSvc: surveyEditorDataSvc,
                    ModalService: ModalService
                });

                
            });
        });

        describe('Testing surveyEditorCtrl controller properties', function () {
            beforeEach(function () {
                surveysEditorCtrl.sortableOptions.orderChanged(eventmock);
                
            });
            it('should define required properties', function () {
                expect(surveysEditorCtrl.surveyEditor).toBeDefined();
                expect(surveysEditorCtrl.selectSurveyId).toBeDefined();
                expect(surveysEditorCtrl.sortableOptions.orderChanged).toBeDefined();
                expect(surveysEditorCtrl.sortableOptions.accept).toBeDefined();
                expect(surveysEditorCtrl.sortableOptions.containment).toBeDefined();
            });
            
            it('should receive parameters value', function () {
                expect(surveysEditorCtrl.surveyEditor).toEqual(surveyEditorMock);
                expect(surveysEditorCtrl.selectSurveyId).toEqual('3');
                expect(pageSvc.movePage).toHaveBeenCalled();
                expect(pageSvc.getAllBySurveyId).toHaveBeenCalledWith(eventmock.source.itemScope.page.SurveyID);
                expect(surveysEditorCtrl.sortableOptions.accept).not.toBe(null);
            });
        });

        describe('Testing loadSurvey function', function () {
            beforeEach(function () {
                surveysEditorCtrl.loadSurvey(surveysEditorCtrl.selectSurveyId);
                scope.$digest();
            });
            it('should load the survey successfully', function () {
                
                expect(questionSvc.setSelectedSurveyId).toHaveBeenCalled();
                expect(pageSvc.getAllBySurveyId).toHaveBeenCalled();
                expect(surveyEditorDataSvc.getSurvey).toHaveBeenCalled();
            });

            it('show the expected valued', function () {
                expect(surveysEditorCtrl.surveyEditor.survey.SurveyId).toEqual(3);
                expect(surveysEditorCtrl.surveyEditor.survey.Name).toEqual("abc");
                expect(surveysEditorCtrl.surveyEditor.survey.Status).toEqual("OPEN");
                expect(surveysEditorCtrl.surveyEditor.survey.LayoutId).toEqual(1);
                expect(surveysEditorCtrl.surveyEditor.survey.CreatedDate).toEqual("Apr 09, 2015 03:52 PM");
                expect(surveysEditorCtrl.surveyEditor.survey.PageOrder).toEqual(0);
                expect(surveysEditorCtrl.surveyTitleDisplay).toEqual('abc(OPEN)');
            });
        });
    });
})();