﻿(function() {
    'use strict';
    describe('Testing editQuestionCtrl controller', function() {
        var ctrl,
            scope,
            questionSvc,
            q,
            instanceController;

        beforeEach(function() {
            module('svt');
            inject(function($rootScope, $controller, $q) {
                scope = $rootScope.$new();
                q = $q;
                questionSvc = jasmine.createSpyObj('questionSvc',
                [
                    'getQuestionTypes', 'getModes', 'toggleIsShowQuestionEditor', 
                    'addNew', 'isSingleChoice', 'isMultipleChoice', 'updateById',
                    'getAllById', 'getNameQuestionType', 'updateStatusModes', 'getDefaultAdvanceSettings',
                    'populateAnswerAlternatives'
                ]);
                questionSvc.getQuestionTypes.and.returnValue({ id: 'text', name: 'Text' });
                questionSvc.getModes.and.returnValue({ mode: 'Edit' });
                questionSvc.populateAnswerAlternatives.and.returnValue([{ Name: '' }]);
                questionSvc.getDefaultAdvanceSettings.and.returnValue({ Name: '', RequiredValidation: { IsRequired: false } });

                instanceController = function() {
                    ctrl = $controller('editQuestionCtrl', {
                        $scope: scope,
                        questionSvc: questionSvc,
                        ModalService: {},
                        constantSvc: {}
                    });
                };
            });
        });

        describe('Testing controller properties', function () {
            it('should define required properties', function () {
                instanceController();
                expect(ctrl.question).toBeDefined();
                expect(ctrl.questionTypes).toBeDefined();
                expect(ctrl.questionTypeSelected).toBeDefined();
                expect(ctrl.questionType).toBeDefined();
                expect(ctrl.modes).toBeDefined();
            });

            it('should initialize default properties by calling service successfully', function() {
                instanceController();
                expect(ctrl.questionTypes).toEqual({ id: 'text', name: 'Text' });
                expect(ctrl.modes).toEqual({ mode: 'Edit' });
            });
        });

        describe('Testing cancelEditQuestion function', function () {
            it('should cancel editing question', function () {
                scope.singleChoiceQuestionCtrl = {};
                scope.multipleChoiceQuestionCtrl = {};
                instanceController();
                ctrl.question = {
                    Id: 1,
                    answers: 'a',
                    type: 'b'
                };
                ctrl.cancelEditQuestion();
                scope.$digest();

                expect(scope.singleChoiceQuestionCtrl.answerSingleChoice).toEqual('a');
                expect(ctrl.questionTypeSelected).toEqual('b');
                expect(questionSvc.toggleIsShowQuestionEditor).toHaveBeenCalledWith(1);
            });
        });

        describe('Testing doneEditQuestion function', function () {
            beforeEach(function () {
                instanceController();
                ctrl.questionTypeSelected = 'singleChoice';
                ctrl.question = {
                    Id: 1,
                    SurveyId: 2,
                    PageDefinitionId: 3,
                    Heading: {
                        Items: [{
                            Text: 'a'
                        }]
                    }
                };
            });

            it('should prepare data before updating question', function() {
                questionSvc.isSingleChoice.and.returnValue(true);
                scope.singleChoiceQuestionCtrl = {
                    answerSingleChoice: [{ id: 'Opt-1', value: 'Option 1' }]
                };
                questionSvc.updateById.and.returnValue({ $promise: q.when({ Status: true }) });
                ctrl.doneEditQuestion();
                scope.$digest();

                expect(questionSvc.isSingleChoice).toHaveBeenCalledWith('singleChoice');
            });

            it('should show error message when updating question unsuccessfully', function() {
                questionSvc.isSingleChoice.and.returnValue(false);
                questionSvc.isMultipleChoice.and.returnValue(false);
                questionSvc.updateById.and.returnValue({ $promise: q.when({ Status: false }) });
                spyOn(toastr, 'error');
                ctrl.doneEditQuestion();
                scope.$digest();

                expect(toastr.error).toHaveBeenCalledWith('Update question was not successfully.');
            });

            it('should show success message when updating question successfully', function () {
                questionSvc.isSingleChoice.and.returnValue(false);
                questionSvc.isMultipleChoice.and.returnValue(false);
                questionSvc.updateById.and.returnValue({ $promise: q.when({ Status: true }) });
                spyOn(toastr, 'success');
                ctrl.doneEditQuestion();
                scope.$digest();

                expect(toastr.success).toHaveBeenCalledWith('Update question was successfully.');
                expect(questionSvc.toggleIsShowQuestionEditor).toHaveBeenCalledWith(1);
                expect(questionSvc.getAllById).toHaveBeenCalledWith(2, 3);
            });
        });

        describe('Testing selectQuestionType function', function () {
            it('should select question type successfully', function() {
                instanceController();
                ctrl.questionTypeSelected = 'singleChoice';
                questionSvc.getNameQuestionType.and.returnValue('Single Choice');
                ctrl.selectQuestionType();
                scope.$digest();

                expect(questionSvc.getNameQuestionType).toHaveBeenCalledWith('singleChoice');
                expect(questionSvc.updateStatusModes).toHaveBeenCalledWith('singleChoice');
                expect(ctrl.questionType).toEqual('Single Choice');
            });
        });
    });
})();