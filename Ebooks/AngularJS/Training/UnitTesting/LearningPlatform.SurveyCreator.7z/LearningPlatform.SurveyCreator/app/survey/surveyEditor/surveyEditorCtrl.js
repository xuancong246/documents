﻿(function () {
    'use strict';

    angular
        .module('svt')
        .controller('surveyEditorCtrl', editSurveyCtrl);

    editSurveyCtrl.$inject = ['$scope', '$routeParams', '$route', 'pageSvc', 'questionSvc', 'surveyEditorDataSvc', 'ModalService'];

    function editSurveyCtrl($scope, $routeParams, $route, pageSvc, questionSvc, surveyEditorDataSvc, ModalService) {
        /* jshint -W040 */
        var vm = this;
        
        vm.surveyEditor = {
            isAdd: false,
            isShow: false,
            survey: {
                $type: "LearningPlatform.Models.SurveyForm, LearningPlatform",
                SurveyId: 0,
                Name: '',
                Status: '',
                LayoutId: 0,
                PageOrder: 0,
                SurveySettings: null
            }
        };
        vm.surveyTitleDisplay = '';
        vm.showSurveyEditor = showSurveyEditor;
        vm.selectSurveyId = 0;
        vm.loadSurvey = loadSurvey;
        vm.isSelectedSurveyId = isSelectedSurveyId;
        vm.pages = { data: [] };

        vm.sortableOptions = {
            orderChanged: function (event) {
                movePage(event);
            },
            containment: 'body',
            accept: function (sourceItemHandleScope) {
                questionSvc.hideOldQuestionEditor();
                questionSvc.hideOldQuestionCreator();
                pageSvc.hidePageEditor();
                return (sourceItemHandleScope.itemScope.page) ? true : false;
            }
        };

        function init() {
            loadSurvey($routeParams.id);
        }

        init();

        function showSurveyEditor() {
            showImportForm(vm.surveyEditor);
        }

        function showImportForm(surveyEditor) {
            ModalService.showModal({
                templateUrl: 'survey/common/createSurveyDialog/create-survey-dialog.html',
                controller: 'createSurveyDialogCtrl',
                inputs: {
                    editor: surveyEditor
                }
            }).then(function (modal) {
                modal.element.modal();
                modal.close.then(function (result) {
                    if (result.status) {
                        vm.surveyTitleDisplay = getSurveyTitleDisplay(result.survey.Name, result.survey.Status);
                    }
                });
            });
        }

        function movePage(event) {
            if (pageSvc.isThankYouPage(vm.pages.data[event.source.index]) || pageSvc.isThankYouPage(vm.pages.data[event.dest.index])) {
                toastr.warning('Cannot move thank you page');
                $route.reload();
                return;
            }

            var movingPage = event.source.itemScope.page;
            var newIndexPosition = event.dest.index;
            var oldIndexPosition = event.source.index;
            var page = {
                PageId: movingPage.Id,
                SurveyId: movingPage.SurveyId,
                NewIndexPosition: newIndexPosition,
                OldIndexPosition: oldIndexPosition
            };
            pageSvc.movePage(page).$promise.then(function (response) {
                if (!response.Status) return;
                pageSvc.getAllBySurveyId(page.SurveyId);
            });
        }

        function loadSurvey(surveyId) {
            vm.selectSurveyId = surveyId;
            questionSvc.setSelectedSurveyId(vm.selectSurveyId);
            
            vm.pages = pageSvc.getAllBySurveyId(vm.selectSurveyId);

            surveyEditorDataSvc.getSurvey(surveyId).$promise.then(function (surveyResponse) {
                vm.surveyEditor.survey.SurveyId = surveyResponse.Id;
                vm.surveyEditor.survey.Name = surveyResponse.Name;
                vm.surveyEditor.survey.Status = surveyResponse.Status;
                vm.surveyEditor.survey.LayoutId = surveyResponse.LayoutId;
                vm.surveyEditor.survey.CreatedDate = surveyResponse.CreatedDate;
                vm.surveyEditor.survey.SurveySettings = surveyResponse.SurveySettings;
                vm.surveyEditor.survey.PageOrder = surveyResponse.TopFolder.OrderType;
                vm.surveyTitleDisplay = getSurveyTitleDisplay(vm.surveyEditor.survey.Name, vm.surveyEditor.survey.Status);
            });
        }

        function getSurveyTitleDisplay(surveyTitle, status) {
            return surveyTitle + '(' + status + ')';
        }

        function isSelectedSurveyId(surveyId) {
            return vm.selectSurveyId == surveyId;
        }
    }
})();