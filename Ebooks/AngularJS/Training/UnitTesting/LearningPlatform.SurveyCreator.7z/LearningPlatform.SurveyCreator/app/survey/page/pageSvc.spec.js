﻿(function() {
    'use strict';
    describe('Testing pageSvc service', function() {
        var pageDataSvc;

        beforeEach(function () {
            module('svt');
            pageDataSvc = jasmine.createSpyObj('pageDataSvc', ['addPage', 'getAllBySurveyId']);
            module(function($provide) {
                $provide.value('pageDataSvc', pageDataSvc);
            });
        });

        describe('Testing addPage function', function() {
            it('should call service to add page', inject(function (pageSvc) {
                pageSvc.addPage(1, 2, 3);
                var page = {
                    Id: null,
                    Name: 'Untitled',
                    Position: 2,
                    SurveyId: 2,
                    ParentId: 3,
                    ResponseStatus: 'NotTaken'
                };

                expect(pageDataSvc.addPage).toHaveBeenCalledWith(page);
            }));
        });

        describe('Testing getAllBySurveyId function', function() {
            it('should return pages', inject(function (pageSvc, $q) {
                pageDataSvc.getAllBySurveyId.and.returnValue({ $promise: $q.when([{ Id: 1, name: 'a' }, { Id: 2, name: 'b' }]) });
                var result = pageSvc.getAllBySurveyId(1);
                var expectedResult = [{ Id: 1, name: 'a' }, { Id: 2, name: 'b' }];

                expect(pageDataSvc.getAllBySurveyId).toHaveBeenCalledWith(1);
                expect(angular.toJson(expectedResult)).toEqual(angular.toJson(result));
            }));
        });

        describe('Testing getPageIndexByPageId function', function() {
            it('should return null when cannot find pageId', inject(function (pageSvc) {
                var result = pageSvc.getPageIndexByPageId('000');

                expect(result).toEqual(null);
            }));

            it('should return number when can find pageId', inject(function (pageSvc, $q) {
                pageDataSvc.getAllBySurveyId.and.returnValue({ $promise: $q.when([{ Id: 1, name: 'a' }, { Id: 2, name: 'b' }]) });
                pageSvc.getAllBySurveyId(1);
                var result = pageSvc.getPageIndexByPageId(2);

                expect(result).toEqual(1);
            }));
        });

        describe('Testing findPageIndexById function', function () {
            var array = [];
            beforeEach(function() {
                array = [{ Id: 1, name: 'a' }, { Id: 2, name: 'b' }];
            });

            it('should return -1 when cannot find value in array', inject(function (pageSvc) {
                var result = pageSvc.findPageIndexById(array, 3);

                expect(result).toEqual(-1);
            }));

            it('should return number when can find value in array', inject(function (pageSvc) {
                var result = pageSvc.findPageIndexById(array, 2);

                expect(result).toEqual(1);
            }));
        });
    });
})();