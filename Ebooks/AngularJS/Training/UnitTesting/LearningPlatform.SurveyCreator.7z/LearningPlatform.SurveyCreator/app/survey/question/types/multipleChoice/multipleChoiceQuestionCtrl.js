﻿(function () {
    'use strict';

    angular
        .module('svt')
        .controller('multipleChoiceQuestionCtrl', multipleChoiceQuestionCtrl);

    multipleChoiceQuestionCtrl.$inject = ['$timeout'];

    function multipleChoiceQuestionCtrl($timeout) {
        /* jshint -W040 */
        var vm = this;

        vm.addOption = addOption;
        vm.removeOption = removeOption;
        vm.answerMultipleChoice = [
            { id: 'Opt-1', value: 'Option 1' }
        ];

        vm.sortableOptionsSingleChoice = {
            itemMoved: function () { },
            orderChanged: function () { },
            containment: 'body',
            accept: function (sourceItemHandleScope) {
                return (sourceItemHandleScope.itemScope.answer) ? true : false;
            }
        };

        function addOption() {
            var id = Object.keys(vm.answerMultipleChoice).length + 1;
            var answer = {
                id: 'Opt-' + id,
                value: 'Option ' + id
            };
            vm.answerMultipleChoice.push(answer);
            $timeout(function () {
                document.getElementById(answer.id).select();
            }, 0);
        }

        function removeOption(index) {
            vm.answerMultipleChoice.splice(index, 1);
        }
    }
})();