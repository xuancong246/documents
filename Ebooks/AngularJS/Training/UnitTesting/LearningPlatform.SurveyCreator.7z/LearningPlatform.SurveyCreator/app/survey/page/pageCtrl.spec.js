﻿(function () {
    'use stric';
    describe('Testing pageCtrl controller', function () {
        var pageCtrl, scope, ModalService, pageSvc, questionSvc, constantSvc,q,
            ModelValueMock = {},
            question = {},
            modes = {},
            Questiontype = { code: 'SingleChoiceQuestionDefinition', name: 'Single Choice' },
            response = {Status: true},
            isShowQuestionEditor = { value: {} },
            isShowQuestionCreator = { value: {} },
            questionsInPage = {},
            isShowPageEditor = { value: {} },
            id = {},
            eventMock = {
                stopPropagation: function() {
                    
                }
            }


        beforeEach(function() {
            module('svt');

            inject(function($rootScope, $controller, $q, $injector) {
                scope = $rootScope.$new();
                scope.$parent = {
                    $parent: {
                        modelValue: [ModelValueMock]
                    }
                };
                scope.createQuestionCtrl = {
                    questionTypeSelected: {},
                    resetAdvanceSetting: function() {
                    }
                };
                scope.index = 0;

                ModalService = jasmine.createSpyObj('ModalService', ['showModal']);
                ModalService.showModal.and.callFake(function() {
                    var modal = {
                        element: {
                            modal: function() {}
                        }
                    }
                    return modal;
                });

                pageSvc = jasmine.createSpyObj('pageSvc', [
                    'getAllBySurveyId',
                    'getIsShowPageEditor',
                    'getAllById',
                    'hidePageEditor',
                    'setIdToShowPageEditor',
                    'toggleIsShowPageEditor',
                    'addPage',
                    'isThankYouPage',
                    'updatePage'
                ]);
                pageSvc.getIsShowPageEditor.and.returnValue(isShowPageEditor);
                pageSvc.updatePage.and.returnValue({ $promise: $q.when(response) });
                
                questionSvc = jasmine.createSpyObj('questionSvc', [
                    'setSelectedSurveyId',
                    'getModes',
                    'getIsShowQuestionEditor',
                    'getIsShowQuestionCreator',
                    'getAllById',
                    'hideOldQuestionEditor',
                    'hideOldQuestionCreator',
                    'getCodeQuestionType',
                    'updateStatusModes',
                    'getTotalQuestion',
                    'getNumberCurrentQuestionOfEditor',
                    'toggleIsShowQuestionEditor',
                    'getNameQuestionType',
                    'toggleIsShowQuestionCreator'
                ]);
                questionSvc.getIsShowQuestionEditor.and.returnValue(isShowQuestionEditor);
                questionSvc.getIsShowQuestionCreator.and.returnValue(isShowQuestionCreator);
                questionSvc.getModes.and.returnValue(modes);
                questionSvc.getAllById.and.returnValue(questionsInPage);
                questionSvc.getTotalQuestion.and.returnValue(1);
                questionSvc.getNumberCurrentQuestionOfEditor.and.returnValue(2);
                questionSvc.getNameQuestionType.and.returnValue(Questiontype.name);

                constantSvc = $injector.get('constantSvc');

                pageCtrl = $controller('pageCtrl', {
                    $scope: scope,
                    ModalService: ModalService,
                    pageSvc: pageSvc,
                    questionSvc: questionSvc,
                    constantSvc: constantSvc
                });
                pageSvc.addPage.and.returnValue({ $promise: $q.when(response) });
            });
        });

        describe('Testing pageCtrl controller properties', function() {
            it('should define required properties', function() {
                expect(pageCtrl.pageIndex).toBeDefined();
                expect(pageCtrl.pages).toBeDefined();
                expect(pageCtrl.totalPage).toBeDefined();
                expect(pageCtrl.modes).toBeDefined();
                expect(pageCtrl.isShowQuestionEditor).toBeDefined();
                expect(pageCtrl.isShowQuestionCreator).toBeDefined();
                expect(pageCtrl.isShowPageEditor).toBeDefined();
                expect(pageCtrl.currentPage).toBeDefined();
                expect(pageCtrl.questionsInPage).toBeDefined();
                expect(pageCtrl.generalConstant).toBeDefined();
            });

            it('should receive parameters value', function() {
                expect(pageCtrl.pageIndex).toEqual(0);
                expect(pageCtrl.pages).toEqual([ModelValueMock]);
                expect(pageCtrl.totalPage).toEqual([ModelValueMock].length);
                expect(pageCtrl.modes).toEqual(modes);
                expect(pageCtrl.isShowQuestionEditor).toEqual(isShowQuestionEditor);
                expect(pageCtrl.isShowQuestionCreator).toEqual(isShowQuestionCreator);
                expect(pageCtrl.isShowPageEditor).toEqual(isShowPageEditor);
                expect(pageCtrl.currentPage).toEqual([ModelValueMock][0]);
                expect(pageCtrl.questionsInPage).toEqual(questionsInPage);
            });
        });

        describe('Testing showQuestionEditor function', function() {
            beforeEach(function() {
                pageCtrl.showQuestionEditor(question, 0);
            });

            it('should show Question Editor', function() {
                expect(questionSvc.hideOldQuestionEditor).toHaveBeenCalled();
                expect(questionSvc.hideOldQuestionCreator).toHaveBeenCalled();
                expect(pageSvc.hidePageEditor).toHaveBeenCalled();
                expect(questionSvc.getCodeQuestionType).toHaveBeenCalledWith(question.$type);
                expect(questionSvc.getNumberCurrentQuestionOfEditor).toHaveBeenCalledWith(question, 0);
                expect(questionSvc.toggleIsShowQuestionEditor).toHaveBeenCalledWith(question.Id);
            });

            it('should update values for properties', function() {
                expect(pageCtrl.numberTotalQuestionOfEditor).toEqual(1);
                expect(pageCtrl.numberCurrentQuestionOfEditor).toEqual(2);
            });
        });

        describe('Testing showQuestionCreator function', function() {
            beforeEach(function() {
                pageCtrl.showQuestionCreator(Questiontype.code);
            });
            it('should show Question Creator', function() {
                expect(questionSvc.getTotalQuestion).toHaveBeenCalled();
                expect(questionSvc.hideOldQuestionEditor).toHaveBeenCalled();
                expect(questionSvc.hideOldQuestionCreator).toHaveBeenCalled();
                expect(pageSvc.hidePageEditor).toHaveBeenCalled();
                expect(questionSvc.updateStatusModes).toHaveBeenCalledWith(Questiontype.code);
                expect(questionSvc.getNameQuestionType).toHaveBeenCalledWith(Questiontype.code);
                expect(questionSvc.toggleIsShowQuestionCreator).toHaveBeenCalledWith(pageCtrl.currentPage.Id);
            });
            it('should update values for properties', function () {
                expect(scope.createQuestionCtrl.questionTypeSelected).toEqual(Questiontype.code);
                expect(scope.createQuestionCtrl.questionType).toEqual(Questiontype.name);
                expect(pageCtrl.numberTotalQuestionInCreator).toEqual(2);
            });
        });

        describe('Testing showPageEditor function', function() {
            it('should show Page Editor successfully', function () {
                pageCtrl.showPageEditor(id);

                expect(pageSvc.setIdToShowPageEditor).toHaveBeenCalledWith(id);
                expect(pageSvc.hidePageEditor).toHaveBeenCalled();
                expect(questionSvc.hideOldQuestionEditor).toHaveBeenCalled();
                expect(questionSvc.hideOldQuestionCreator).toHaveBeenCalled();
                expect(pageSvc.toggleIsShowPageEditor).toHaveBeenCalled();
            });
        });

        describe('Testing showPageEditor function', function () {
            it('should show Page Editor successfully', function () {
                pageCtrl.showPageEditor(id);

                expect(pageSvc.setIdToShowPageEditor).toHaveBeenCalledWith(id);
                expect(pageSvc.hidePageEditor).toHaveBeenCalled();
                expect(questionSvc.hideOldQuestionEditor).toHaveBeenCalled();
                expect(questionSvc.hideOldQuestionCreator).toHaveBeenCalled();
                expect(pageSvc.toggleIsShowPageEditor).toHaveBeenCalled();
            });
        });

        describe('Testing onAddPage function', function () {
           
            it('should show message and add page successfully',function () {
                pageCtrl.onAddPage();
                scope.$digest();

                expect(pageSvc.getAllBySurveyId).toHaveBeenCalled();
            });

            it('should show error message and not add page', inject(function ($q) {
                response = { Status: false };
                pageSvc.addPage.and.returnValue({ $promise: $q.when(response) });
                pageCtrl.onAddPage();
                scope.$digest();

                expect(pageSvc.getAllBySurveyId).not.toHaveBeenCalled();
            }));
        });

        describe('Testing onEditPage function', function () {
            it('should show Page Editor successfully', function () {
                pageCtrl.onEditPage();
                
                expect(pageSvc.hidePageEditor).toHaveBeenCalled();
                
            });
        });

    });
})();