﻿(function() {
    'use strict';
    describe('Testing createQuestionCtrl controller', function() {
        var ctrl,
            scope,
            questionSvc,
            q,
            instanceController;

        beforeEach(function() {
            module('svt');
            inject(function($rootScope, $controller, $q) {
                scope = $rootScope.$new();
                scope.pageCtrl = { currentPage: { Id: 1 } };
                q = $q;
                questionSvc = jasmine.createSpyObj('questionSvc',
                [
                    'getInitLanguageString', 'getSelectedSurveyId', 'getQuestionTypes', 'getModes',
                    'toggleIsShowQuestionCreator', 'getNameQuestionType', 'updateStatusModes',
                    'getCurrentPosition', 'isSingleChoice', 'isMultipleChoice',
                    'addNew', 'getAllById', 'getDefaultAdvanceSettings', 'populateAnswerAlternatives'
                ]);
                questionSvc.getInitLanguageString.and.returnValue({ language: 'en_US' });
                questionSvc.getSelectedSurveyId.and.returnValue(1);
                questionSvc.getQuestionTypes.and.returnValue({ id: 'text', name: 'Text' });
                questionSvc.getModes.and.returnValue({ mode: 'Edit' });
                questionSvc.getDefaultAdvanceSettings.and.returnValue({ Name: 'a', RequiredValidation: { IsRequired: false } });

                instanceController = function() {
                    ctrl = $controller('createQuestionCtrl', {
                        $scope: scope,
                        questionSvc: questionSvc
                    });
                };
            });
        });

        describe('Testing controller properties', function () {
            it('should define required properties', function () {
                instanceController();
                expect(ctrl.pageId).toBeDefined();
                expect(ctrl.question).toBeDefined();
                expect(ctrl.questionTypes).toBeDefined();
                expect(ctrl.questionTypeSelected).toBeDefined();
                expect(ctrl.questionType).toBeDefined();
                expect(ctrl.modes).toBeDefined();
                expect(ctrl.settings).toBeDefined();
            });

            it('should initialize default properties by calling service successfully', function() {
                instanceController();
                expect(ctrl.pageId).toEqual(1);
                expect(ctrl.question.Heading).toEqual({ language: 'en_US' });
                expect(ctrl.question.Text).toEqual({ language: 'en_US' });
                expect(ctrl.question.SurveyId).toEqual(1);
                expect(ctrl.questionTypes).toEqual({ id: 'text', name: 'Text' });
                expect(ctrl.modes).toEqual({ mode: 'Edit' });
                expect(ctrl.settings).toEqual({ Name: 'a', RequiredValidation: { IsRequired: false } });
            });
        });

        describe('Testing cancelAddQuestion function', function() {
            it('should reset form', function () {
                scope.singleChoiceQuestionCtrl = {};
                scope.multipleChoiceQuestionCtrl = {};
                instanceController();
                var oldQuestionType = ctrl.question.$type;
                ctrl.cancelAddQuestion();
                scope.$digest();

                expect(questionSvc.toggleIsShowQuestionCreator).toHaveBeenCalledWith(1);
                expect(oldQuestionType).not.toEqual(ctrl.question.$type);
                expect(ctrl.question.$type).toEqual('');
                expect(scope.singleChoiceQuestionCtrl.answerSingleChoice).toEqual([{ id: 'Opt-1', value: 'Option 1' }]);
                expect(scope.multipleChoiceQuestionCtrl.answerMultipleChoice).toEqual([{ id: 'Opt-1', value: 'Option 1' }]);
            });
        });

        describe('Testing doneCreateQuestion function', function () {
            beforeEach(function() {
                questionSvc.getInitLanguageString.and.returnValue({
                    language: 'en_US',
                    Items: [{ Text: 'a' }]
                });
            });

            it('should prepare data before adding question', function() {
                questionSvc.isSingleChoice.and.returnValue(true);
                scope.singleChoiceQuestionCtrl = {
                    answerSingleChoice: [{ id: 'Opt-1', value: 'Option 1' }]
                };
                questionSvc.addNew.and.returnValue({ $promise: q.when({ Status: true }) });
                instanceController();
                ctrl.questionTypeSelected = 'singleChoice';
                ctrl.pageId = 1;
                ctrl.doneCreateQuestion();
                scope.$digest();

                expect(questionSvc.getCurrentPosition).toHaveBeenCalledWith(1);
                expect(questionSvc.isSingleChoice).toHaveBeenCalledWith('singleChoice');
            });

            it('should show error message when adding new question unsuccessfully', function() {
                questionSvc.isSingleChoice.and.returnValue(false);
                questionSvc.isMultipleChoice.and.returnValue(false);
                questionSvc.addNew.and.returnValue({ $promise: q.when({ Status: false }) });
                spyOn(toastr, 'error');
                instanceController();
                ctrl.questionTypeSelected = 'singleChoice';
                ctrl.pageId = 1;
                ctrl.doneCreateQuestion();
                scope.$digest();

                expect(toastr.error).toHaveBeenCalledWith('Create question was not successfully.');
            });

            it('should show success message when adding new question successfully', function () {
                ctrl.question.SurveyId = 1;
                questionSvc.isSingleChoice.and.returnValue(false);
                questionSvc.isMultipleChoice.and.returnValue(false);
                questionSvc.addNew.and.returnValue({ $promise: q.when({ Status: true }) });
                spyOn(toastr, 'success');
                instanceController();
                ctrl.questionTypeSelected = 'singleChoice';
                ctrl.pageId = 1;
                ctrl.doneCreateQuestion();
                scope.$digest();

                expect(toastr.success).toHaveBeenCalledWith('Create question was successfully.');
                expect(questionSvc.getAllById).toHaveBeenCalledWith(1, 1);
                expect(questionSvc.toggleIsShowQuestionCreator).toHaveBeenCalledWith(1);
            });
        });

        describe('Testing selectQuestionType function', function() {
            it('should select question type successfully', function() {
                instanceController();
                ctrl.questionTypeSelected = 'singleChoice';
                questionSvc.getNameQuestionType.and.returnValue('Single Choice');
                ctrl.selectQuestionType();
                scope.$digest();

                expect(questionSvc.getNameQuestionType).toHaveBeenCalledWith('singleChoice');
                expect(questionSvc.updateStatusModes).toHaveBeenCalledWith('singleChoice');
                expect(ctrl.questionType).toEqual('Single Choice');
            });
        });
    });
})();