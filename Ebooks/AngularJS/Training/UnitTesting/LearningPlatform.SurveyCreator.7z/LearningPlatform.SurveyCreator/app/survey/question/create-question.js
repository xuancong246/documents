﻿(function () {
    'use strict';

    angular
        .module('svt')
        .directive('createQuestion', createQuestion);

    function createQuestion() {
        var directive = {
            restrict: 'E',
            templateUrl: 'survey/question/create-question.html',
            controller: 'createQuestionCtrl',
            controllerAs: 'createQuestionCtrl'
        };

        return directive;
    }
})();