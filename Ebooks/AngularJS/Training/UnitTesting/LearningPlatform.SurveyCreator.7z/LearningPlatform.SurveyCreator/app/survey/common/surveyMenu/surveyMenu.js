﻿(function () {
    'use strict';

    angular
        .module('svt')
        .directive('surveyMenu', surveyMenu);

    function surveyMenu() {
        return {
            restrict: "E",
            scope:{
                activeMenu:'@'
            },
            templateUrl: 'survey/common/surveyMenu/surveyMenu.html',
            controller: 'surveyMenuCtrl',
            controllerAs: 'vm'
        };
    }
})();