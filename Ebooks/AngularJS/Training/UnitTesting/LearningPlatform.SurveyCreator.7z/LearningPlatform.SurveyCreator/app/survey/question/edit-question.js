﻿(function () {
    'use strict';

    angular
        .module('svt')
        .directive('editQuestion', editQuestion);

    function editQuestion() {
        var directive = {
            restrict: 'E',
            templateUrl: 'survey/question/edit-question.html',
            controller: 'editQuestionCtrl',
            controllerAs: 'editQuestionCtrl'
        };

        return directive;
    }
})();