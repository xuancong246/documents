﻿(function () {
    'use strict';

    angular
        .module('svt')
        .directive('numericField', numericField);

    function numericField() {
        var directive = {
            restrict: 'E',
            templateUrl: 'survey/question/types/numeric/numeric-field.html'
        };

        return directive;
    }
})();