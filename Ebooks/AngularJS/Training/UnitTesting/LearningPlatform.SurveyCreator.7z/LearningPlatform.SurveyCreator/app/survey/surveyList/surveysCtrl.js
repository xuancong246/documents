﻿(function () {
    'use strict';

    angular
        .module('svt')
        .controller('surveysCtrl', surveysCtrl);

    surveysCtrl.$inject = ['$scope', 'ModalService', 'pageSvc', 'questionSvc', 'surveyDataSvc', 'constantSvc'];

    function surveysCtrl($scope, ModalService, pageSvc, questionSvc, surveyDataSvc, constantSvc) {
        /* jshint -W040 */
        var vm = this;

        vm.surveysFound = 0;
        vm.searchString = '';
        vm.surveys = getDefaultSurveys();
        vm.paging = getDefaultPaging();
        vm.surveyEditor = null;
        vm.showSurveyEditor = showSurveyEditor;
        vm.loadAllSurveys = loadAllSurveys;
        vm.delete = deleteSurvey;
        vm.duplicate = duplicate;
        vm.analyse = analyse;
        vm.search = search;
        vm.loadMore = loadMore;
        vm.count = count;

        function showSurveyEditor () {
            vm.surveyEditor = {
                isAdd: true,
                isShow: false,
                survey: {
                    Name: '',
                    LayoutId: 0,
                    PageOrder: 0,
                    SurveySettings: {
                        $type: "SurveySettings",
                        Id: 0,
                        EnableBackButton: true,
                        ResumeRespondent: false
                    }
                }
            };
            showImportForm(vm.surveyEditor);
        }

        function showImportForm(surveyEditor) {
            ModalService.showModal({
                templateUrl: 'survey/common/createSurveyDialog/create-survey-dialog.html',
                controller: 'createSurveyDialogCtrl',
                inputs: {
                    editor: surveyEditor
                }
            }).then(function (modal) {
                modal.element.modal();
                modal.close.then(function (result) {
                    if (result.status) {
                        vm.search();
                    }
                });
            });
        }

        function loadAllSurveys() {
            surveyDataSvc.getAllSurveys().$promise.then(function (response) {
                populateSurveys(response);
            });
        }

        function deleteSurvey(surveyId, $event) {
            var message = constantSvc.messages.deleteSurvey;
            ModalService.showModal({
                templateUrl: 'survey/common/deleteDialog/deleteDialog.html',
                controller: 'deleteDialogCtrl',
                scope: {
                    message: message
                }
            }).then(function (modal) {
                modal.element.modal();
                modal.close.then(function (result) {
                    if (result) {
                        alert('Not yet implement delete: ' + surveyId);
                    }
                });
            });
        }

        function duplicate(id) {
            alert('Not yet implement duplicate: ' + id);
        }

        function analyse(id) {
            alert('Not yet implement analyse: ' + id);
        }

        function search() {
            vm.surveys = getDefaultSurveys();
            vm.paging = getDefaultPaging();

            surveyDataSvc.search(getSearchForm(vm.searchString, vm.paging)).$promise.then(function (response) {
                populateSurveys(response);
                updatePaging(response.length);
            });
            vm.count();
        }

        function loadMore() {
            surveyDataSvc.search(getSearchForm(vm.searchString, vm.paging)).$promise.then(function (response) {
                populateSurveys(response);
                updatePaging(response.length);
            });
        }

        function count() {
            surveyDataSvc.count(getCountForm(vm.searchString)).$promise.then(function (response) {
                vm.surveysFound = response.count;
            });
        }

        function getCountForm(searchString) {
            return {
                $type: "LearningPlatform.Models.SurveyCountForm, LearningPlatform",
                searchString: searchString,
                count:0
            };
        }

        function getSearchForm(searchString, paging) {
            return {
                $type: "LearningPlatform.Models.SurveySearchForm, LearningPlatform",
                searchString: searchString,
                paging: paging
            };
        }
        
        function populateSurveys(response) {
            for (var index = 0; index < response.length; index++) {
                vm.surveys.data.push({
                    surveyId: response[index].Id,
                    name: response[index].Name,
                    status: response[index].Status,
                    createdDate: response[index].CreatedDate,
                    modifiedDate: response[index].ModifiedDate,
                });
            }
        }

        function updatePaging(size) {
            vm.paging.start += size;
            if (size === 0 || vm.surveysFound === vm.surveys.data.length) {
                vm.paging.hashNext = false;
            } else {
                vm.paging.hashNext = true;
            }
        }

        function getDefaultPaging() {
            return {
                $type: "LearningPlatform.Models.Paging, LearningPlatform",
                start: 0,
                limit: 10,
                hashNext: false
            };
        }

        function getDefaultSurveys() {
            return { data: [] };
        }

        vm.search();
    }
})();