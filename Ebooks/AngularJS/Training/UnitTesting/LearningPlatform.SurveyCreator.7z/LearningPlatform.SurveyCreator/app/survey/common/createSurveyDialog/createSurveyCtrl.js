﻿(function () {
    'use strict';

    angular
        .module('svt')
        .controller('createSurveyCtrl', createSurveyCtrl);

    createSurveyCtrl.$inject = [
        '$scope',
        'createSurveyDataSvc', 'layoutDataSvc'];

    function createSurveyCtrl($scope, createSurveyDataSvc, layoutDataSvc) {
        /* jshint -W040 */
        var vm = this;
        vm.editor = $scope.editor;
        vm.refresh = $scope.refresh;

        vm.layouts = {data:[]};
        vm.Status = [
            { code: 'OPEN', name: 'Open' },
            { code: 'CLOSE', name: 'Close' },
            { code: 'PENDING', name: 'Pending' }
        ];

        function resetForm() {
            vm.editor.survey = {
                $type: "LearningPlatform.Models.SurveyForm, LearningPlatform",
                SurveyId: 0,
                Name: '',
                Status: '',
                LayoutId:0
            };
        }

        function isAdd() {
            return vm.editor.isAdd;
        }

        function init() {
            if (isAdd()) {
                resetForm();
            }
        }

        init();
        loadLayouts();

        vm.cancel = cancel;
        vm.doAction = doAction;

        function cancel() {
            if (isAdd()) {
                resetForm();
            }
            closeForm();
        }

        function closeForm() {
            vm.editor.isShow = false;
        }

        function doAction() {
            if (vm.editor.survey.Name === undefined || vm.editor.survey.Name === '') {
                toastr.warning('Please enter required field.');
                return;
            }
            if (vm.editor.survey.LayoutId === 0) {
                toastr.warning('Please choose a layout.');
                return;
            }
                
            if (isAdd()) {
                createSurveyDataSvc.addSurvey(vm.editor.survey).$promise.then(function (response) {
                    if (!response.Status) {
                        toastr.error('Create survey was not successfully.');
                        return;
                    }
                    toastr.success('Create survey was successfully.');
                    vm.refresh();
                    resetForm();
                    closeForm();
                });
            } else {
                createSurveyDataSvc.updateSurvey(vm.editor.survey).$promise.then(function (response) {
                    if (!response.Status) {
                        toastr.error('Update survey was not successfully.');
                        return;
                    }
                        
                    closeForm();
                    toastr.success('Update survey was successfully.');
                });
            }
        }

        function loadLayouts() {
            layoutDataSvc.getAllLayouts().$promise.then(function (response) {
                for (var index = 0; index < response.length; index++) {
                    vm.layouts.data.push({
                        LayoutId: response[index].Id,
                        Name: response[index].Name,
                        Css: response[index].Css,
                        Templates: response[index].Templates
                    });
                }
            });
        }
    }
})();
