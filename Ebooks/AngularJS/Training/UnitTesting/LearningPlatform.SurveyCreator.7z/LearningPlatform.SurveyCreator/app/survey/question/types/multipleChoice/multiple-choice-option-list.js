﻿(function () {
    'use strict';

    angular
        .module('svt')
        .directive('multipleChoiceOptionList', multipleChoiceOptionList);

    function multipleChoiceOptionList() {
        var directive = {
            restrict: 'E',
            templateUrl: 'survey/question/types/multipleChoice/multiple-choice-option-list.html',
            controller: 'multipleChoiceQuestionCtrl',
            controllerAs: 'multipleChoiceQuestionCtrl'
        };

        return directive;
    }
})();