﻿(function () {
    'use strict';

    angular
        .module('svt')
        .controller('surveyDashboardCtrl', surveyDashboardCtrl);

    surveyDashboardCtrl.$inject = ['$scope', '$routeParams', '$location'];

    function surveyDashboardCtrl($scope, $routeParams, $location) {
        /* jshint -W040 */
        var vm = this;
        vm.surveyId = $routeParams.id;
        vm.editSurvey = function () {
            $location.path('/editsurvey/' + vm.surveyId);
        };
        vm.collectResponses = function () {
            $location.path('/collectResponses/' + vm.surveyId);
        };
    }
})();