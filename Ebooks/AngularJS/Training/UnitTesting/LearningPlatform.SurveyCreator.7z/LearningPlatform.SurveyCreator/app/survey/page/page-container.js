﻿(function () {
    'use strict';

    angular
        .module('svt')
        .directive('pageContainer', page);

    function page() {
        var directive = {
            restrict: 'EA',
            templateUrl: 'survey/page/page-container.html',
            scope: {
                id: '=',
                pagedescription: '=',
                obj: '=',
                index: '=',
                pagetitle: '='
            },
            controller: 'pageCtrl',
            controllerAs: 'pageCtrl'
        };

        return directive;
    }
})();