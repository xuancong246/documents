﻿(function () {
    'use strict';

    angular
        .module('svt')
        .controller('uploadRespondentDialogCtrl', uploadRespondentDialogCtrl);

    uploadRespondentDialogCtrl.$inject = ['$scope', '$element', 'respondentDataSvc', 'close', 'message', 'surveyId'];

    function uploadRespondentDialogCtrl($scope, $element, respondentDataSvc, close, message, surveyId) {
        $scope.message = message;
        $scope.respondentFile = null;
        $scope.uploadFile = uploadFile;
        $scope.chooseFile = chooseFile;

        function uploadFile(result) {
            if (result) {
                if ($scope.respondentFile === null) {
                    toastr.warning('Please choose a file.');
                    return;
                }
                respondentDataSvc.upload(surveyId, $scope.respondentFile).$promise.then(
                    function (response) {
                        toastr.success('Import file was successfully.');
                        $element.modal('hide');
                        close({ status: true, uploadedFileName: response.FileName }, 500);
                    },
                    function (error) {
                        toastr.error(error.data.Message, 'Import file was not successfully');
                    }
                );
            }
        }

        function chooseFile(params) {
            $scope.respondentFile = params.element[0].files[0];
        }

        function reset() {
            $scope.respondentFile = null;
        }
    }
})();