﻿(function () {
    'use strict';

    angular
        .module('svt')
        .controller('questionAdvanceSettingsCtrl', questionAdvanceSettingsCtrl);

    function questionAdvanceSettingsCtrl() {
        /* jshint -W040 */
        var vm = this;

        vm.isShowAdvanceSetting = false;
        vm.showAdvanceSetting = showAdvanceSetting;

        vm.questionOrders = [
             { code: 0, name: 'In Order' },
             { code: 1, name: 'Randomized' },
             { code: 2, name: 'Flipped' },
             { code: 3, name: 'Rotated' }
        ];

        function showAdvanceSetting() {
            vm.isShowAdvanceSetting = !vm.isShowAdvanceSetting;
        }
    }
})();
