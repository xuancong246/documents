﻿(function () {
    'use strict';

    angular
        .module('svt')
        .directive('singleChoiceOptionList', singleChoiceQuestion);

    function singleChoiceQuestion() {
        var directive = {
            restrict: 'E',
            templateUrl: 'survey/question/types/singleChoice/single-choice-option-list.html',
            controller: 'singleChoiceQuestionCtrl',
            controllerAs: 'singleChoiceQuestionCtrl'
        };

        return directive;
    }
})();