﻿(function() {
    'use strict';
    describe('Testing surveyDashboardCtrl controller', function() {
        var dashboardCtrl,
            scope,
            locationMock = {
                path: sinon.stub()
            };

        beforeEach(function () {
            module('svt');
            inject(function ($rootScope, $controller, $location) {
                scope = $rootScope.$new();
                locationMock = $location;

                dashboardCtrl = $controller('surveyDashboardCtrl', {
                    $scope: scope,
                    $routeParams: { id: '123' }
                });
            });
        });

        describe('Testing controller properties', function() {
            it('should define required properties', function () {
                expect(dashboardCtrl.surveyId).toBeDefined();
            });

            it('should receive parameters value', function() {
                expect(dashboardCtrl.surveyId).toEqual('123');
            });
        });

        describe('Testing editSurvey function', function() {
            it('should locate to editSurvey location', function () {
                spyOn(locationMock, 'path');
                dashboardCtrl.editSurvey();
                expect(locationMock.path).toHaveBeenCalledWith('/editsurvey/123');
            });
        });

        describe('Testing collectResponses function', function () {
            it('should locate to collectResponses location', function () {
                spyOn(locationMock, 'path');
                dashboardCtrl.collectResponses();
                expect(locationMock.path).toHaveBeenCalledWith('/collectResponses/123');
            });
        });
    });
})();