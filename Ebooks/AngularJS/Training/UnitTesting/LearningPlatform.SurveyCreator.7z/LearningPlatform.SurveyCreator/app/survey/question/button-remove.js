﻿(function () {
    'use strict';

    angular
        .module('svt')
        .directive('buttonRemove', buttonRemove);

    function buttonRemove() {
        var directive = {
            restrict: 'E',
            scope: {
                item: '='
            },
            link: linkFunc,
            templateUrl: 'survey/question/button-remove.html',
            controller: 'editQuestionCtrl',
            controllerAs: 'editQuestionCtrl'
        };

        return directive;

        function linkFunc(scope, element, attr, controller) {
            element.on('click', function (event) {
                controller.question = scope.item;
                controller.removeQuestion(event);
            });
        }
    }
})();