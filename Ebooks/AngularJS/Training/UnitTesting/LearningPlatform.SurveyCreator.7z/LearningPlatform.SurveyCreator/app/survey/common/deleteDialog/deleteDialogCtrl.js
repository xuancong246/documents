﻿(function () {
    'use strict';

    angular
        .module('svt')
        .controller('deleteDialogCtrl', deleteDialogCtrl);

    deleteDialogCtrl.$inject = ['$scope', 'close', 'message'];

    function deleteDialogCtrl($scope, close, message) {
        $scope.message = message;
        $scope.close = function (result) {
            close(result, 500);
        };
    }
})();