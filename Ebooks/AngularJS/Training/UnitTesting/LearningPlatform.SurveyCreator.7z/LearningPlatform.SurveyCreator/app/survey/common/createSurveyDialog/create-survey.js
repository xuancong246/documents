﻿(function () {
    'use strict';

    angular
        .module('svt')
        .directive('createSurvey', createSurvey);

    function createSurvey() {
        var directive = {
            restrict: 'EA',
            templateUrl: 'survey/common/createSurveyDialog/create-survey.html',
            controller: 'createSurveyCtrl',
            controllerAs: 'vm',
            scope: {
                editor: '=',
                refresh:'&'
            }
        };

        return directive;
    }
})();