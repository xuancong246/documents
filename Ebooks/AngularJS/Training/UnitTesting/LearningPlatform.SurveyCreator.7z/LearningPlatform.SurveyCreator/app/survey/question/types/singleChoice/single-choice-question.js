﻿(function () {
    'use strict';

    angular
        .module('svt')
        .directive('singleChoiceQuestion', singleChoicePage);

    function singleChoicePage() {
        var directive = {
            restrict: 'E',
            scope: {
                question: '='
            },
            templateUrl: 'survey/question/types/singleChoice/single-choice-question.html'
        };

        return directive;
    }
})();