﻿(function () {
    'use strict';

    angular
        .module('svt')
        .directive('multipleChoiceOption', multipleChoiceOption);

    function multipleChoiceOption() {
        var directive =  {
            restrict: 'E',
            templateUrl: 'survey/question/types/multipleChoice/multiple-choice-option.html',
            require: '^?multipleChoiceQuestionCtrl'
        };

        return directive;
    }
})();