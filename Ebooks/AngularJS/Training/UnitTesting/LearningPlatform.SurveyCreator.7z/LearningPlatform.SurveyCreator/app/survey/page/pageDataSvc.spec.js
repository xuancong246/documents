﻿(function() {
    'use strict';
    describe('Testing pageDataSvc service', function () {
        var httpBackend,
            pageDataSvc,
            hostMock = 'http://localhost:52071/api';

        beforeEach(function () {
            module('svt');
            inject(function ($injector) {
                httpBackend = $injector.get('$httpBackend');
                pageDataSvc = $injector.get('pageDataSvc');
            });
        });

        describe('Testing addPage function', function () {
            it('should add page successfully', function () {
                var page = { SurveyId: 1 };
                httpBackend.expectPOST(hostMock + '/surveys/1/definition/pages').respond({ result: true });
                var result = pageDataSvc.addPage(page);
                httpBackend.flush();

                expect(angular.toJson(result)).toContain('result');
            });
        });

        describe('Testing updatePage function', function () {
            it('should update page successfully', function () {
                var page = { SurveyId: 1, Id: 2 };
                httpBackend.expectPUT(hostMock + '/surveys/1/definition/pages/2').respond({ result: true });
                var result = pageDataSvc.updatePage(page);
                httpBackend.flush();

                expect(angular.toJson(result)).toContain('result');
            });
        });

        describe('Testing deletePage function', function () {
            it('should delete page successfully', function () {
                var page = { SurveyId: 1, Id: 2 };
                httpBackend.expectDELETE(hostMock + '/surveys/1/definition/pages/2').respond({ result: true });
                var result = pageDataSvc.deletePage(page);
                httpBackend.flush();

                expect(angular.toJson(result)).toContain('result');
            });
        });

        describe('Testing getAllBySurveyId function', function () {
            it('should return pages', function () {
                var surveyId = 1;
                httpBackend.expectGET(hostMock + '/surveys/1/definition/pages').respond([{ Id: 1, name: 'a' }, { Id: 2, name: 'b' }]);
                var result = pageDataSvc.getAllBySurveyId(surveyId);
                httpBackend.flush();

                var expectedResult = [{ Id: 1, name: 'a' }, { Id: 2, name: 'b' }];
                expect(angular.toJson(expectedResult)).toEqual(angular.toJson(result));
            });
        });

        describe('Testing movePage function', function () {
            it('should move page successfully', function () {
                var item = { SurveyId: 1 };
                httpBackend.expectPATCH(hostMock + '/surveys/1/pages').respond({ result: true });
                var result = pageDataSvc.movePage(item);
                httpBackend.flush();

                expect(angular.toJson(result)).toContain('result');
            });
        });
    });
})();