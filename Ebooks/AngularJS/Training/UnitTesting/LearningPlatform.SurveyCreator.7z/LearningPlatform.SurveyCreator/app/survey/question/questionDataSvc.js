﻿(function() {
    'use strict';

    angular
        .module('svt')
        .factory('questionDataSvc', questionDataSvc);

    questionDataSvc.$inject = ['$resource', 'host'];

    function questionDataSvc($resource, host) {
        var dataService = {
            getAllById: getAllById,
            addNew: addNew,
            updateById: updateById,
            deleteById: deleteById,
            moveToAnotherPage: moveToAnotherPage,
            moveInsidePage: moveInsidePage
        };

        return dataService;

        function getAllById(surveyId, pageId) {
            return $resource(host + '/surveys/:surveyId/definition/pages/:pageId/questions', { surveyId: '@surveyId', pageId: '@pageId' }, { 'GetAllById': { method: 'GET', isArray: true } })
                .GetAllById({ surveyId: surveyId, pageId: pageId });
        }

        function addNew(question) {
            return $resource(host + '/surveys/:surveyId/definition/questions', { surveyId: '@surveyId' }, { 'AddNew': { method: 'POST' } })
                .AddNew({ surveyId: question.SurveyId }, JSON.stringify(question));
        }

        function updateById(question) {
            return $resource(host + '/surveys/:surveyId/definition/questions/:questionId', { surveyId: '@surveyId', questionId: '@questionId' }, { 'EditById': { method: 'PUT' } })
                .EditById({ surveyId: question.SurveyId, questionId: question.Id }, JSON.stringify(question));
        }

        function deleteById(question) {
            return $resource(host + '/surveys/:surveyId/definition/questions/:questionId', { surveyId: '@surveyId', questionId: '@questionId' }, { 'DeleteById': { method: 'DELETE' } })
                .DeleteById({ surveyId: question.SurveyId, questionId: question.Id });
        }

        function moveToAnotherPage(movingQuestion) {
            return $resource(host + '/surveys/:surveyId/pages/:pageId/questions', { surveyId: '@surveyId', pageId: '@pageId' }, { 'MoveToAnotherPage': { method: 'PATCH' } })
                .MoveToAnotherPage({ surveyId: movingQuestion.SurveyId, pageId: movingQuestion.DeparturePageId }, JSON.stringify(movingQuestion));
        }

        function moveInsidePage(movingQuestion) {
            return $resource(host + '/surveys/:surveyId/pages/:pageId/questions/:questionId', { surveyId: '@surveyId', pageId: '@pageId', questionId: '@questionId' }, { 'MoveInsidePage': { method: 'PATCH' } })
                .MoveInsidePage({ surveyId: movingQuestion.SurveyId, pageId: movingQuestion.DeparturePageId, questionId: movingQuestion.QuestionId }, JSON.stringify(movingQuestion));
        }
    }
})();