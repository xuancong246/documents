﻿(function() {
    'use strict';
    describe('Testing surveysCtrl controller', function() {
        var surveysCtrl,
            scope,
            surveyDataSvc,
            q,
            instanceController;

        beforeEach(function() {
            module('svt');
            inject(function ($rootScope, $controller, $q) {
                scope = $rootScope.$new();
                q = $q;
                surveyDataSvc = jasmine.createSpyObj('surveyDataSvc', ['search', 'count', 'getAllSurveys']);
                surveyDataSvc.search.and.returnValue({ $promise: q.when([{ Id: 1, Name: 'abc' }]) });
                surveyDataSvc.count.and.returnValue({ $promise: q.when({ count: 1 }) });

                instanceController = function() {
                    surveysCtrl = $controller('surveysCtrl', {
                        $scope: scope,
                        ModalService: {},
                        pageSvc: {},
                        questionSvc: {},
                        surveyDataSvc: surveyDataSvc,
                        constantSvc: {}
                    });
                };
            });
        });

        describe('Testing controller properties', function () {
            it('should define required properties', function () {
                instanceController();
                expect(surveysCtrl.surveysFound).toBeDefined();
                expect(surveysCtrl.searchString).toBeDefined();
                expect(surveysCtrl.surveys).toBeDefined();
                expect(surveysCtrl.surveyEditor).toBeDefined();
                expect(surveysCtrl.paging).toBeDefined();
            });
        });

        describe('Testing loadAllSurveys function', function() {
            it('should change surveys list when having data', function() {
                surveyDataSvc.getAllSurveys.and.returnValue({ $promise: q.when([{ Id: 1 }]) });
                instanceController();
                surveysCtrl.loadAllSurveys();
                scope.$digest();

                expect(surveyDataSvc.getAllSurveys).toHaveBeenCalled();
                expect(surveysCtrl.surveys.data.length).toBeGreaterThan(0);
                expect(surveysCtrl.surveys.data[0].surveyId).toEqual(1);
            });
        });

        describe('Testing search function', function() {
            it('should call service search function with default paging', function() {
                instanceController();
                surveysCtrl.searchString = '';
                surveysCtrl.search();

                expect(surveyDataSvc.search).toHaveBeenCalledWith({
                    $type: "LearningPlatform.Models.SurveySearchForm, LearningPlatform",
                    searchString: '',
                    paging: {
                        $type: "LearningPlatform.Models.Paging, LearningPlatform",
                        start: 0,
                        limit: 10,
                        hashNext: false
                    }
                });
            });

            it('should keep default surveys and paging when searching returns no data', function () {
                surveyDataSvc.search.and.returnValue({ $promise: q.when([]) });
                instanceController();
                surveysCtrl.search();
                scope.$digest();

                expect(surveysCtrl.surveys.data.length).toEqual(0);
                expect(surveysCtrl.paging.start).toEqual(0);
                expect(surveysCtrl.paging.hashNext).toEqual(false);
            });

            it('should change surveys list and paging when searching returns data', function() {
                instanceController();
                surveysCtrl.search();
                scope.$digest();

                expect(surveysCtrl.surveys.data.length).toBeGreaterThan(0);
                expect(surveysCtrl.paging.start).toBeGreaterThan(0);
            });

            it('should call count function', function () {
                instanceController();
                spyOn(surveysCtrl, 'count');
                surveysCtrl.search();
                scope.$digest();

                expect(surveysCtrl.count).toHaveBeenCalled();
            });
        });

        describe('Testing loadMore function', function() {
            it('should call service search function', function() {
                instanceController();
                surveysCtrl.searchString = '';
                surveysCtrl.paging = {};
                surveyDataSvc.search.calls.reset();
                surveysCtrl.loadMore();

                expect(surveyDataSvc.search).toHaveBeenCalledWith({
                    $type: "LearningPlatform.Models.SurveySearchForm, LearningPlatform",
                    searchString: '',
                    paging: {}
                });
            });

            it('should change surveys list and paging when loading more results', function() {
                instanceController();
                var data = [], paging = {};
                surveysCtrl.surveys.data = [];
                surveysCtrl.paging = {};
                surveysCtrl.loadMore();
                scope.$digest();

                expect(surveysCtrl.surveys.data).not.toEqual(data);
                expect(surveysCtrl.paging).not.toEqual(paging);
            });
        });

        describe('Testing count function', function() {
            it('should call service count function', function () {
                instanceController();
                surveysCtrl.searchString = '';
                surveyDataSvc.count.calls.reset();
                surveysCtrl.count();

                expect(surveyDataSvc.count).toHaveBeenCalledWith({
                    $type: "LearningPlatform.Models.SurveyCountForm, LearningPlatform",
                    searchString: '',
                    count: 0
                });
            });

            it('should change found surveys when counting returns data', function() {
                instanceController();
                surveysCtrl.surveysFound = 0;
                surveysCtrl.count();
                scope.$digest();

                expect(surveysCtrl.surveysFound).toBeGreaterThan(0);
            });
        });
    });
})();