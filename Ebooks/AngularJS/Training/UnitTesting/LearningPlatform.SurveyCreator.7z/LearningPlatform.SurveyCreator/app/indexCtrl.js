﻿(function () {
    'use strict';

    angular
        .module('svt')
        .controller('indexCtrl', indexCtrl);

    indexCtrl.$inject = ['$scope', '$location'];

    function indexCtrl($scope, $location) {
        /* jshint -W040 */
        var vm = this;
        vm.goHome = function (){
            $location.path('/');
        };
    }
})();