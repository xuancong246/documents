﻿1) How to install dependencies
	> npm install
2) How to start Selenium server
	> webdriver-manager start
3) How to start protractor
	> protractor protractor.conf.js