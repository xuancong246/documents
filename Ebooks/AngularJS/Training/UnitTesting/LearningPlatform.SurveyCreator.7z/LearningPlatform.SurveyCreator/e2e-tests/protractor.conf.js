﻿exports.config = {
    seleniumAddress: 'http://localhost:4444/wd/hub',
    //seleniumServerJar: 'C:/Users/pxcong/AppData/Roaming/npm/node_modules/protractor/selenium/selenium-server-standalone-2.45.0.jar',
    //seleniumPort: 4444,
    //seleniumArgs: [],
    allScriptsTimeout: 11000,

    //specs: [
    //  '*.js'
    //],

    capabilities: {
        'browserName': 'chrome'
    },

    onPrepare: function () {
        requirePage = function (name) {
            return require(__dirname + "/pages/" + name);
        };
        requireLib = function (name) {
            return require(__dirname + "/lib/" + name);
        };
        getBaseUrl = function () {
            return 'http://localhost:4001/app/';
        };
    },

    suites: {
        survey: 'tests/app/survey/*[Ss]pec.js'
    },

    baseUrl: 'http://localhost:4001/app/',

    framework: 'jasmine',

    jasmineNodeOpts: {
        defaultTimeoutInterval: 30000
    },
    restartBrowserBetweenTests: true
};
