﻿var CreateQuestionDialog = function (html) {
    var self = this,
        rootElement = html;

    self.setTitle = setTitle;
    self.setDescription = setDescription;
    self.clickDone = clickDone;
    self.clickAddSingleChoiceOption = clickAddSingleChoiceOption;
    self.clickAddMultipleChoiceOption = clickAddMultipleChoiceOption;

    function setTitle(value) {
        rootElement.element(by.model('createQuestionCtrl.question.Heading.Items[0].Text')).sendKeys(value);
    }

    function setDescription(value) {
        rootElement.element(by.model('createQuestionCtrl.question.Text.Items[0].Text')).sendKeys(value);
    }

    function clickDone() {
        return rootElement.element(by.cssContainingText('button[ng-click="createQuestionCtrl.doneCreateQuestion()"]', 'Done')).click();
    }

    function clickAddSingleChoiceOption() {
        return rootElement.element(by.tagName('single-choice-alternative-list')).element(by.css('div.add-single-choice-question')).click();
    }

    function clickAddMultipleChoiceOption() {
        return rootElement.element(by.tagName('multiple-choice-alternative-list')).element(by.css('div.add-single-choice-question')).click();
    }

};

module.exports = CreateQuestionDialog;