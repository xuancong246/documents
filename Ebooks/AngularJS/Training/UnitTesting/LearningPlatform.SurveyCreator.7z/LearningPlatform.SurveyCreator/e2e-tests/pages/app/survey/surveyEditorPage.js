﻿var BasePage = requirePage('common/basePage');
var SurveyEditorPage = function (url) {
    var self = this,
        q = require('q');

    self.url = url || '#/editsurvey/:surveyId';
    self.spanSurveyTitle = element(by.css('span.survey-edit-title[ng-click="vm.showSurveyEditor()"]'));

    self.clickSurveyTitle = clickSurveyTitle;
    self.getSurveyTitleText = getSurveyTitleText;
    self.isDisplayedSurveyTitle = isDisplayedSurveyTitle;

    function clickSurveyTitle() {
        return self.spanSurveyTitle.click();
    }

    function getSurveyTitleText() {
        return self.spanSurveyTitle.getText();
    }

    function isDisplayedSurveyTitle() {
        return self.spanSurveyTitle.isDisplayed();
    }

};

SurveyEditorPage.prototype = new BasePage();
SurveyEditorPage.prototype.goTo = function () {
    BasePage.prototype.goTo(this.url);
};

SurveyEditorPage.prototype.at = function () {
    return BasePage.prototype.at(this.url);
};

module.exports = SurveyEditorPage;