﻿var EditSurveyDialog = function () {
    var self = this,
        q = require('q');

    self.pEditSurvey = element(by.css('p.title-question-form[ng-hide="vm.editor.isAdd"]'));
    self.txtTitle = element(by.model('vm.editor.survey.Name'));
    self.cboStatus = element(by.model('vm.editor.survey.Status'));
    self.cboLayout = element(by.model('vm.editor.survey.LayoutId'));
    self.btnClose = element(by.css('button.btn.btn-default[ng-click="vm.cancel()"]'));
    self.btnDone = element(by.css('button.btn.btn-primary[ng-click="vm.doAction()"]'));

    self.isDisplayedPEditSurvey = isDisplayedPEditSurvey;
    self.getEditSurveyText = getEditSurveyText;
    self.appendTitle = appendTitle;
    self.setTitle = setTitle;
    self.setStatus = setStatus;
    self.setLayout = setLayout;
    self.clickCloseDialog = clickCloseDialog;
    self.clickDone = clickDone;

    function isDisplayedPEditSurvey() {
        return self.pEditSurvey.isDisplayed();
    }

    function getEditSurveyText() {
        return self.pEditSurvey.getText();
    }

    function appendTitle(value) {
        return self.txtTitle.sendKeys(value);
    }

    function setTitle(value) {
        var defer = q.defer();
        self.txtTitle.clear().then(function() {
            self.txtTitle.sendKeys(value).then(function() {
                defer.resolve();
            });
        });
        return defer.promise;
    }

    function setStatus(optionText) {
        return self.cboStatus.element(by.cssContainingText('option', optionText)).click();
    }

    function setLayout(optionText) {
        return self.cboLayout.element(by.cssContainingText('option', optionText)).click();
    }

    function clickCloseDialog() {
        return self.btnClose.click();
    }

    function clickDone() {
        return self.btnDone.click();
    }

};

module.exports = EditSurveyDialog;