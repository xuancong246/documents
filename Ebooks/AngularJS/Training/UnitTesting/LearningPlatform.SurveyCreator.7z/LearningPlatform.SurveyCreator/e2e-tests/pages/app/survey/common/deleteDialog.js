﻿var DeleteDialog = function() {
    var self = this,
        parentElement = element(by.css('div.modal div.modal-dialog div.modal-content')),
        q = require('q');

    self.clickCancel = clickCancel;
    self.clickDelete = clickDelete;

    function clickCancel() {
        var defer = q.defer();
        parentElement.element(by.cssContainingText('button.btn.btn-default[ng-click="close(false)"]', 'Cancel')).then(function (ele) {
            ele.click().then(function() {
                defer.resolve();
            });
        });
        return defer.promise;
    }

    function clickDelete() {
        var defer = q.defer();
        parentElement.element(by.cssContainingText('button.btn.btn-primary', 'Delete')).then(function (ele) {
            ele.click().then(function () {
                defer.resolve();
            });
        });
        return defer.promise;
    }

};

module.exports = DeleteDialog;