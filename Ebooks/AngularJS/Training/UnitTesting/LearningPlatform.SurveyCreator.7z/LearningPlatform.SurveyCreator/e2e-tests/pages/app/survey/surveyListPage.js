﻿var BasePage = requirePage('common/basePage');
var SurveyListPage = function(url) {
    var self = this,
        q = require('q');

    self.url = url || '#/surveys';
    self.txtSearchText = element(by.model('vm.searchString'));
    self.btnSearch = element(by.css('input.search-survey-button[ng-click="vm.search()"]'));
    self.btnCreateSurvey = element(by.css('input.search-survey-button[ng-click="vm.showSurveyEditor()"]'));
    self.tblResult = element(by.css('table.table.table-hover'));
    self.dlgCreateSurvey = element(by.css('create-survey[ng-show="vm.surveyEditor.isShow"]'));
    self.spanPagingShowCount = element(by.exactBinding('vm.surveys.data.length'));
    self.surveyFoundCount = element.all(by.exactBinding('vm.surveysFound')).first();
    self.btnLoadMore = element(by.css('input.search-survey-button[ng-click="vm.loadMore()"]'));

    self.getDialogCreateSurvey = getDialogCreateSurvey;
    self.getSurveyShowFoundCount = getSurveyShowFoundCount;
    self.inputSearchText = inputSearchText;
    self.applySearch = applySearch;
    self.clickCreateSurvey = clickCreateSurvey;
    self.getAllRecordsOnPage1 = getAllRecordsOnPage1;
    self.getRecordAt = getRecordAt;
    self.getHeaders = getHeaders;
    self.getCellValue = getCellValue;
    self.clickLink = clickLink;
    self.getHref = getHref;
    self.clickLoadMore = clickLoadMore;

    function getDialogCreateSurvey() {
        return self.dlgCreateSurvey;
    }

    function getSurveyShowFoundCount() {
        var defer = q.defer();
        self.spanPagingShowCount.getText().then(function (text) {
            // Sample value for text: Displaying 10/15 survey(s).
            var showCountValue = text.split(' ')[1];
            var tempArr = showCountValue.split('/');
            defer.resolve({
                show: tempArr[0],
                found: tempArr[1]
            });
        });
        return defer.promise;
    }

    function inputSearchText(text) {
        return self.txtSearchText.sendKeys(text);
    }

    function applySearch() {
        return self.btnSearch.click();
    }

    function clickCreateSurvey() {
        return self.btnCreateSurvey.click();
    }

    function getAllRecordsOnPage1() {
        return self.tblResult.all(by.exactRepeater('survey in vm.surveys.data'));
    }

    function getHeaders() {
        return self.tblResult.all(by.css('thead tr th')).map(function (th) {
            return th.getText();
        });
    }

    function getRecordAt(index) {
        return getAllRecordsOnPage1().get(index);
    }

    function getCellValue(rowIndex, title) {
        var defer = q.defer();
        getHeaders().then(function (headers) {
            var cellIndex = -1;
            for (var i = 0; i < headers.length; i++) {
                if (headers[i] === title) {
                    cellIndex = i;
                    break;
                }
            }

            getRecordAt(rowIndex).then(function (tr) {
                tr.all(by.css('td')).get(cellIndex).getText().then(function (text) {
                    defer.resolve(text);
                });
            });
        });
        return defer.promise;
    }

    function clickLink(rowIndex, title) {
        var defer = q.defer();
        getHeaders().then(function (headers) {
            var cellIndex = -1;
            for (var i = 0; i < headers.length; i++) {
                if (headers[i] === title) {
                    cellIndex = i;
                    break;
                }
            }

            getRecordAt(rowIndex).then(function (tr) {
                tr.all(by.css('td')).get(cellIndex).element(by.css('a')).click().then(function () {
                    defer.resolve();
                });
            });
        });
        return defer.promise;
    }

    function getHref(rowIndex, title) {
        var defer = q.defer();
        getHeaders().then(function (headers) {
            var cellIndex = -1;
            for (var i = 0; i < headers.length; i++) {
                if (headers[i] === title) {
                    cellIndex = i;
                    break;
                }
            }

            getRecordAt(rowIndex).then(function (tr) {
                tr.all(by.css('td')).get(cellIndex).element(by.css('a')).getAttribute('href').then(function(href) {
                    defer.resolve(href);
                });
            });
        });
        return defer.promise;
    }

    function clickLoadMore() {
        return self.btnLoadMore.click();
    }

};

SurveyListPage.prototype = new BasePage();
SurveyListPage.prototype.goTo = function () {
    BasePage.prototype.goTo(this.url);
};

SurveyListPage.prototype.at = function () {
    return BasePage.prototype.at(this.url);
};

module.exports = SurveyListPage;