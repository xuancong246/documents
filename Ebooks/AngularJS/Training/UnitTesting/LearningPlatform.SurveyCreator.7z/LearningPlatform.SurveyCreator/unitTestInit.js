﻿angular.module('svt', ['ngRoute', 'ngResource']);
