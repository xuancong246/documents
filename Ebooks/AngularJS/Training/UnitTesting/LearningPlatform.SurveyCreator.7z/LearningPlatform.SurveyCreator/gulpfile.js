var gulp = require('gulp'),
    concat = require('gulp-concat'),
    templateCache = require('gulp-angular-templatecache'), 
    jshint = require('gulp-jshint'),
    cdnizer = require("gulp-cdnizer"),
    runSequence = require('run-sequence'),
    clean = require('gulp-clean'),
    changed = require('gulp-changed'),
    useref = require('gulp-useref'),
    gulpif = require('gulp-if'),
    uglify = require('gulp-uglify'),
    minifyCss = require('gulp-minify-css'),
    debug = require('gulp-debug'),
    rev = require('gulp-rev'),
    revReplace = require('gulp-rev-replace'),
    sourcemaps = require('gulp-sourcemaps'),
    webserver = require('gulp-webserver'),
    order = require("gulp-order"),
    replace = require('gulp-replace'),
    preprocess = require('gulp-preprocess'),
    plumber = require('gulp-plumber');
 
var sourceFiles = {
  scripts: ['app/**/*.js'],
  assets: ['assets/**/*'],
  fonts: ['bower_components/font-awesome/fonts/**/*', 'bower_components/bootstrap/fonts/**/*'],
  angularTemplates: ['app/**/*.html', '!app/index.html'],
  bowerComponents: ['bower_components/**/*']
};

var destionationPaths = {
    base: 'dest',
    temp: 'temp',
    fonts: 'dest/assets/fonts',
    assets: 'dest/assets',
    bowerComponents: 'dest/bower_components'
};

gulp.task('default', ['build'], function () {
});


gulp.task('build', function (callback) {
    runSequence('lint', ['buildJs', 'copy'], callback);
});

gulp.task('clean', function (callback) {
    runSequence(['buildClean', 'tempClean'], callback);
});

gulp.task('tempClean', function () {
    return gulp.src(destionationPaths.temp, { read: false })
        .pipe(clean());
});


gulp.task('buildClean', function() {
    return gulp.src(destionationPaths.base, { read: false })
        .pipe(clean());
});

gulp.task('lint', function() {
    return gulp.src(sourceFiles.scripts)
        .pipe(plumber())
        .pipe(jshint())
        .pipe(jshint.reporter('jshint-stylish'));
});

gulp.task('angularTemplates', function() {

    return gulp.src(sourceFiles.angularTemplates)
        .pipe(order(['**/*.html']))
        .pipe(templateCache('surveyCreatorTemplates.js', { module: 'svt' }))
        .pipe(gulp.dest(destionationPaths.temp));
});

 
gulp.task('buildJs', ['angularTemplates'], function () {
    var useRefAssets = useref.assets();
    var addsrc = require("gulp-add-src");

    return gulp.src('./app/index.html')
        .pipe(cdnizer(
        {
            relativeRoot: './app/',
            files: ['google:angular-resource', 'google:angular', 'google:angular-route', 'google:jquery']
        }))        
        .pipe(useRefAssets)
        .pipe(addsrc('temp/surveyCreatorTemplates.js'))
        .pipe(order(['**/surveyCreator.js']))
        .pipe(gulpif('**/surveyCreator.js', preprocess()))
        .pipe(gulpif('**/surveyCreator*.js', concat('surveyCreator.js')))
        .pipe(gulpif('*.js', uglify()))
        .pipe(gulpif('*.css', minifyCss()))
        .pipe(rev())
        .pipe(useRefAssets.restore())
        .pipe(revReplace())  // Substitute in new filenames
        .pipe(useref())
        .pipe(gulp.dest(destionationPaths.base));
});



gulp.task('serve', ['build', 'watch'],function () {
    gulp.src('dest/')
      .pipe(webserver({
          livereload: true,
          port: 4000,
          directoryListing: false,
          open: true
      }));
});

gulp.task('serveDev', ['lint', 'watchDev'], function () {
    gulp.src('.')
      .pipe(webserver({
          livereload: true,
          port: 4001,
          directoryListing: false,
          open: 'http://localhost:4001/app/'
      }));
});


gulp.task('copy', function (callback) {
    runSequence(['copyFonts', 'copyAssets'], callback);
});

gulp.task('copyAssets', function () {
    return gulp.src(sourceFiles.assets)
        .pipe(gulp.dest(destionationPaths.assets));
});

gulp.task('copyFonts', function () {
    return gulp.src(sourceFiles.fonts)
        .pipe(gulp.dest(destionationPaths.fonts));
});

gulp.task('copyBowerComponents', function () {
    return gulp.src(sourceFiles.bowerComponents)
        .pipe(changed(destionationPaths.bowerComponents))
        .pipe(gulp.dest(destionationPaths.bowerComponents));
});


gulp.task('watch', function() {
    gulp.watch([sourceFiles.scripts, sourceFiles.angularTemplates], ['build']).on('error', swallowError);
});

gulp.task('watchDev', function() {
    gulp.watch([sourceFiles.scripts, sourceFiles.angularTemplates], ['lint']).on('error', swallowError);
});

function swallowError(error) { error.end(); }